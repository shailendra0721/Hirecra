import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    id: '1',
    name: 'A. Lin',
    role: 'Product Designer',
    company: 'Figma',
    avatar: '/avatar_alin.jpg',
    quote: 'I rebuilt my resume in 20 minutes and started getting callbacks. The templates are beautiful and ATS-friendly.',
  },
  {
    id: '2',
    name: 'J. Ortiz',
    role: 'Software Engineer',
    company: 'Stripe',
    avatar: '/avatar_jortiz.jpg',
    quote: 'The ATS checker gave me a roadmap. I finally felt in control of my job search instead of just hoping.',
  },
  {
    id: '3',
    name: 'M. Patel',
    role: 'Marketing Manager',
    company: 'Notion',
    avatar: '/avatar_mpatel.jpg',
    quote: 'The tracker turned chaos into a calm weekly routine. I never lost track of an application again.',
  },
];

export function TestimonialsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const cards = cardsRef.current;

    if (!section || !heading || !cards) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(heading,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: heading,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          }
        }
      );

      gsap.fromTo(cards.children,
        { y: 70, rotateX: 8, opacity: 0 },
        {
          y: 0,
          rotateX: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: cards,
            start: 'top 80%',
            end: 'top 50%',
            scrub: 1,
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="relative w-full py-20 lg:py-28 bg-[#F6F8FB] z-[70]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-[#0B0F1A]">
            Hear from people who moved forward
          </h2>
        </div>

        {/* Testimonial Cards */}
        <div 
          ref={cardsRef}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {testimonials.map((testimonial) => (
            <div 
              key={testimonial.id}
              className="card-modern p-6 lg:p-8 hover:-translate-y-2 hover:shadow-[0_24px_60px_rgba(11,15,26,0.15)] transition-all duration-300 will-change-transform"
              style={{ perspective: '1000px' }}
            >
              <Quote className="w-10 h-10 text-[#2F8E92]/20 mb-4" />
              
              <p className="text-[#0B0F1A] text-lg leading-relaxed mb-6">
                "{testimonial.quote}"
              </p>
              
              <div className="flex items-center gap-4">
                <img 
                  src={testimonial.avatar} 
                  alt={testimonial.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
                <div>
                  <p className="font-semibold text-[#0B0F1A]">{testimonial.name}</p>
                  <p className="text-sm text-[#6B7280]">
                    {testimonial.role} at {testimonial.company}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
