import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Clock } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const blogPosts = [
  {
    id: '1',
    title: 'How to tailor your resume without losing your voice',
    excerpt: 'Learn the art of customizing your resume for each application while maintaining your authentic professional story.',
    image: '/resume_builder_workspace.jpg',
    category: 'Resume Tips',
    readTime: 5,
  },
  {
    id: '2',
    title: 'A simple system for following up after interviews',
    excerpt: 'Never wonder when or how to follow up again. This proven system keeps you top of mind without being pushy.',
    image: '/ats_laptop_review.jpg',
    category: 'Interview',
    readTime: 4,
  },
  {
    id: '3',
    title: 'Remote job search: setting boundaries and winning offers',
    excerpt: 'Navigate the unique challenges of remote job hunting and land a position that respects your work-life balance.',
    image: '/tracker_phone_coffee.jpg',
    category: 'Remote Work',
    readTime: 6,
  },
];

export function BlogSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const cards = cardsRef.current;

    if (!section || !heading || !cards) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(heading,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: heading,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          }
        }
      );

      gsap.fromTo(cards.children,
        { y: 60, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: cards,
            start: 'top 75%',
            end: 'top 45%',
            scrub: 1,
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="relative w-full py-20 lg:py-28 bg-[#F6F8FB] z-[70]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Heading */}
        <div ref={headingRef} className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-12">
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#0B0F1A]">
              From the blog
            </h2>
            <p className="mt-3 text-[#6B7280] max-w-lg">
              Career advice, tips, and insights to help you move forward.
            </p>
          </div>
          <button className="mt-4 lg:mt-0 text-[#2F8E92] hover:text-[#267a7e] font-medium flex items-center gap-2 group">
            View all articles
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Blog Cards */}
        <div 
          ref={cardsRef}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {blogPosts.map((post) => (
            <article 
              key={post.id}
              className="card-modern overflow-hidden hover:-translate-y-2 hover:shadow-[0_24px_60px_rgba(11,15,26,0.15)] transition-all duration-300 cursor-pointer group will-change-transform"
            >
              <div className="aspect-[16/10] overflow-hidden">
                <img 
                  src={post.image} 
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              
              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-xs font-medium text-[#2F8E92] bg-[#2F8E92]/10 px-2 py-1 rounded-full">
                    {post.category}
                  </span>
                  <span className="text-xs text-[#6B7280] flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {post.readTime} min read
                  </span>
                </div>
                
                <h3 className="font-semibold text-[#0B0F1A] text-lg group-hover:text-[#2F8E92] transition-colors line-clamp-2">
                  {post.title}
                </h3>
                
                <p className="mt-2 text-sm text-[#6B7280] line-clamp-2">
                  {post.excerpt}
                </p>
                
                <span className="mt-4 inline-flex items-center text-sm text-[#2F8E92] font-medium group-hover:underline">
                  Read more
                  <ArrowRight className="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
