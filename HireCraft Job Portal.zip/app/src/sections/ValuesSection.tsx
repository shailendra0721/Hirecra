import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function ValuesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const sublineRef = useRef<HTMLParagraphElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const subline = sublineRef.current;

    if (!section || !headline || !subline) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0% - 30%)
      scrollTl.fromTo(headline.children,
        { y: '40vh', opacity: 0 },
        { y: 0, opacity: 1, stagger: 0.05, ease: 'none' },
        0
      );
      
      scrollTl.fromTo(subline,
        { y: '18vh', opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.1
      );

      // EXIT (70% - 100%)
      scrollTl.fromTo(headline,
        { y: 0, opacity: 1 },
        { y: '-18vh', opacity: 0.25, ease: 'power2.in' },
        0.7
      );
      
      scrollTl.fromTo(subline,
        { y: 0, opacity: 1 },
        { y: '-10vh', opacity: 0, ease: 'power2.in' },
        0.75
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="relative w-full h-screen bg-[#0B0F1A] overflow-hidden z-[80] flex items-center justify-center"
    >
      {/* Grain overlay for dark section */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E")`,
      }} />
      
      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div ref={headlineRef} className="will-change-transform">
          <h2 className="heading-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-white">
            CLARITY OVER NOISE.
          </h2>
          <h2 className="heading-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-[#2F8E92] mt-2">
            ACTION OVER HYPE.
          </h2>
        </div>
        
        <p 
          ref={sublineRef}
          className="mt-10 text-lg lg:text-xl text-white/70 max-w-2xl mx-auto will-change-transform"
        >
          We build tools that respect your time and help you move forward.
        </p>
      </div>
    </section>
  );
}
