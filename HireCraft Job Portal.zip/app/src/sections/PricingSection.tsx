import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { Check, X } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

gsap.registerPlugin(ScrollTrigger);

const plans = [
  {
    id: 'free',
    name: 'Free',
    description: 'Perfect for getting started',
    monthlyPrice: 0,
    yearlyPrice: 0,
    features: [
      { text: 'Save up to 10 jobs', included: true },
      { text: 'Build 1 resume', included: true },
      { text: 'Basic ATS scan', included: true },
      { text: 'Job search filters', included: true },
      { text: 'Application tracker', included: false },
      { text: 'AI career assistant', included: false },
      { text: 'Advanced ATS analysis', included: false },
      { text: 'Priority support', included: false },
    ],
    cta: 'Start free',
    highlighted: false,
  },
  {
    id: 'pro',
    name: 'Pro',
    description: 'For serious job seekers',
    monthlyPrice: 12,
    yearlyPrice: 99,
    features: [
      { text: 'Unlimited job saves', included: true },
      { text: 'Unlimited resumes', included: true },
      { text: 'Advanced ATS analysis', included: true },
      { text: 'AI career coaching', included: true },
      { text: 'Full application tracker', included: true },
      { text: 'Mock interviews', included: true },
      { text: 'Salary insights', included: true },
      { text: 'Priority support', included: false },
    ],
    cta: 'Start Pro trial',
    highlighted: true,
  },
  {
    id: 'teams',
    name: 'Teams',
    description: 'For organizations',
    monthlyPrice: 29,
    yearlyPrice: 290,
    features: [
      { text: 'Everything in Pro', included: true },
      { text: 'Team collaboration', included: true },
      { text: 'Shared templates', included: true },
      { text: 'Analytics dashboard', included: true },
      { text: 'Admin controls', included: true },
      { text: 'SSO integration', included: true },
      { text: 'Dedicated support', included: true },
      { text: 'Custom onboarding', included: true },
    ],
    cta: 'Contact sales',
    highlighted: false,
  },
];

export function PricingSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const [isYearly, setIsYearly] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const cards = cardsRef.current;

    if (!section || !heading || !cards) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(heading,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: heading,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          }
        }
      );

      gsap.fromTo(cards.children,
        { y: 80, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: cards,
            start: 'top 75%',
            end: 'top 45%',
            scrub: 1,
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      id="pricing"
      className="relative w-full py-20 lg:py-28 bg-[#F6F8FB] z-[70]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-[#0B0F1A]">
            Simple, transparent pricing
          </h2>
          <p className="mt-3 text-[#6B7280] max-w-lg mx-auto">
            Choose the plan that fits your career goals. Upgrade or downgrade anytime.
          </p>
          
          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <span className={`text-sm font-medium ${!isYearly ? 'text-[#0B0F1A]' : 'text-[#6B7280]'}`}>
              Monthly
            </span>
            <Switch
              checked={isYearly}
              onCheckedChange={setIsYearly}
            />
            <span className={`text-sm font-medium ${isYearly ? 'text-[#0B0F1A]' : 'text-[#6B7280]'}`}>
              Yearly
            </span>
            {isYearly && (
              <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-medium">
                Save 30%
              </span>
            )}
          </div>
        </div>

        {/* Pricing Cards */}
        <div 
          ref={cardsRef}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8"
        >
          {plans.map((plan) => (
            <div 
              key={plan.id}
              className={`card-modern p-6 lg:p-8 transition-all duration-300 will-change-transform ${
                plan.highlighted 
                  ? 'lg:-translate-y-2 ring-2 ring-[#2F8E92] shadow-[0_24px_60px_rgba(47,142,146,0.15)]' 
                  : 'hover:-translate-y-2 hover:shadow-[0_24px_60px_rgba(11,15,26,0.15)]'
              }`}
            >
              {plan.highlighted && (
                <span className="inline-block bg-[#2F8E92] text-white text-xs font-semibold px-3 py-1 rounded-full mb-4">
                  Most Popular
                </span>
              )}
              
              <h3 className="text-xl font-bold text-[#0B0F1A]">{plan.name}</h3>
              <p className="text-sm text-[#6B7280] mt-1">{plan.description}</p>
              
              <div className="mt-6 mb-8">
                <span className="text-4xl font-bold text-[#0B0F1A]">
                  ${isYearly ? plan.yearlyPrice : plan.monthlyPrice}
                </span>
                <span className="text-[#6B7280]">/{isYearly ? 'year' : 'month'}</span>
              </div>
              
              <Button 
                className={`w-full mb-8 ${
                  plan.highlighted ? 'btn-primary' : 'bg-gray-100 text-[#0B0F1A] hover:bg-gray-200'
                }`}
              >
                {plan.cta}
              </Button>
              
              <ul className="space-y-3">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-3">
                    {feature.included ? (
                      <div className="w-5 h-5 bg-[#2F8E92]/10 rounded-full flex items-center justify-center flex-shrink-0">
                        <Check className="w-3 h-3 text-[#2F8E92]" />
                      </div>
                    ) : (
                      <div className="w-5 h-5 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <X className="w-3 h-3 text-gray-400" />
                      </div>
                    )}
                    <span className={feature.included ? 'text-[#0B0F1A]' : 'text-gray-400'}>
                      {feature.text}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
