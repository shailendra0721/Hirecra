import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { ArrowRight, ChevronDown } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface HeroSectionProps {
  onGetStarted: () => void;
}

export function HeroSection({ onGetStarted }: HeroSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const scrollHintRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const image = imageRef.current;
    const headline = headlineRef.current;
    const subhead = subheadRef.current;
    const cta = ctaRef.current;
    const scrollHint = scrollHintRef.current;

    if (!section || !image || !headline || !subhead || !cta) return;

    const ctx = gsap.context(() => {
      // Initial state (hidden)
      gsap.set(image, { x: '-60vw', scale: 0.96, opacity: 0 });
      gsap.set(headline.children, { y: 40, opacity: 0 });
      gsap.set(subhead, { y: 24, opacity: 0 });
      gsap.set(cta, { scale: 0.92, opacity: 0 });
      gsap.set(scrollHint, { y: 20, opacity: 0 });

      // Auto-play entrance animation
      const tl = gsap.timeline({ delay: 0.3 });
      
      tl.to(image, {
        x: 0,
        scale: 1,
        opacity: 1,
        duration: 1,
        ease: 'power3.out'
      })
      .to(headline.children, {
        y: 0,
        opacity: 1,
        duration: 0.8,
        stagger: 0.06,
        ease: 'power3.out'
      }, '-=0.6')
      .to(subhead, {
        y: 0,
        opacity: 1,
        duration: 0.6,
        ease: 'power3.out'
      }, '-=0.4')
      .to(cta, {
        scale: 1,
        opacity: 1,
        duration: 0.5,
        ease: 'back.out(1.7)'
      }, '-=0.3')
      .to(scrollHint, {
        y: 0,
        opacity: 1,
        duration: 0.5,
        ease: 'power3.out'
      }, '-=0.2');

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset to visible when scrolling back
            gsap.to(image, { x: 0, y: 0, scale: 1, opacity: 1, duration: 0.3 });
            gsap.to(headline, { x: 0, opacity: 1, duration: 0.3 });
            gsap.to(cta, { y: 0, opacity: 1, duration: 0.3 });
          }
        }
      });

      // EXIT phase (70% - 100%)
      scrollTl.fromTo(image, 
        { x: 0, y: 0, scale: 1, opacity: 1 },
        { x: '-18vw', y: '10vh', scale: 0.92, opacity: 0.25, ease: 'power2.in' },
        0.7
      );
      
      scrollTl.fromTo(headline,
        { x: 0, opacity: 1 },
        { x: '10vw', opacity: 0.2, ease: 'power2.in' },
        0.7
      );
      
      scrollTl.fromTo(cta,
        { y: 0, opacity: 1 },
        { y: '10vh', opacity: 0, ease: 'power2.in' },
        0.75
      );
      
      scrollTl.fromTo(scrollHint,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.7
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="relative w-full h-screen bg-[#F6F8FB] overflow-hidden z-10"
    >
      {/* Dot Grid Background */}
      <div className="absolute inset-0 dot-grid opacity-50" />
      
      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center w-full pt-20">
          {/* Left Image Card */}
          <div 
            ref={imageRef}
            className="relative will-change-transform"
          >
            <div className="relative rounded-[28px] overflow-hidden shadow-[0_18px_50px_rgba(11,15,26,0.15)] aspect-[4/3]">
              <img 
                src="/hero_team_meeting.jpg" 
                alt="Team collaboration"
                className="w-full h-full object-cover"
              />
              {/* Photo credit */}
              <div className="absolute bottom-4 left-4 text-white/80 text-xs font-medium">
                HireCraft Team
              </div>
            </div>
            
            {/* Floating badge */}
            <div className="absolute -bottom-4 -right-4 bg-white rounded-2xl shadow-lg p-4 flex items-center gap-3">
              <div className="w-10 h-10 bg-[#2F8E92]/10 rounded-full flex items-center justify-center">
                <span className="text-[#2F8E92] font-bold text-sm">12k+</span>
              </div>
              <div>
                <p className="text-[#0B0F1A] font-semibold text-sm">Resumes built</p>
                <p className="text-[#6B7280] text-xs">This month</p>
              </div>
            </div>
          </div>

          {/* Right Content */}
          <div className="lg:pl-8">
            <div ref={headlineRef} className="space-y-2">
              <h1 className="heading-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-[#0B0F1A]">
                FIND YOUR
              </h1>
              <h1 className="heading-display text-4xl sm:text-5xl lg:text-6xl xl:text-7xl text-[#2F8E92]">
                NEXT MOVE
              </h1>
            </div>
            
            <p 
              ref={subheadRef}
              className="mt-6 text-lg text-[#6B7280] max-w-md will-change-transform"
            >
              Jobs, resumes, and AI guidance—one calm, focused place to build your career story.
            </p>

            <div ref={ctaRef} className="mt-8 will-change-transform">
              <Button 
                onClick={onGetStarted}
                className="btn-primary text-base px-8 py-6 h-auto group"
              >
                Get started
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>

            <div 
              ref={scrollHintRef}
              className="mt-12 flex items-center gap-2 text-[#6B7280] text-sm will-change-transform"
            >
              <ChevronDown className="w-4 h-4 animate-bounce" />
              <span>Scroll to explore</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
