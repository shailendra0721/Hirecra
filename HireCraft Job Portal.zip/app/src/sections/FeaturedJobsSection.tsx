import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  MapPin, 
  DollarSign, 
  ArrowRight, 
  Figma,
  Code2,
  PenTool
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface FeaturedJobsSectionProps {
  onViewAll: () => void;
}

const featuredJobs = [
  {
    id: '1',
    title: 'Product Designer',
    company: 'Figma',
    location: 'Remote',
    type: 'full-time',
    salary: { min: 110000, max: 140000, currency: '$', period: 'year' },
    description: 'Design intuitive interfaces for millions of creators worldwide.',
    icon: Figma,
    color: '#F24E1E',
  },
  {
    id: '2',
    title: 'Frontend Engineer',
    company: 'Vercel',
    location: 'Hybrid',
    type: 'full-time',
    salary: { min: 120000, max: 160000, currency: '$', period: 'year' },
    description: 'Build the future of web development with React and Next.js.',
    icon: Code2,
    color: '#000000',
  },
  {
    id: '3',
    title: 'Content Strategist',
    company: 'Notion',
    location: 'Remote',
    type: 'contract',
    salary: { min: 70, max: 95, currency: '$', period: 'hour' },
    description: 'Craft compelling narratives that help teams work better.',
    icon: PenTool,
    color: '#000000',
  },
];

export function FeaturedJobsSection({ onViewAll }: FeaturedJobsSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const cards = cardsRef.current;

    if (!section || !heading || !cards) return;

    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(heading,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: heading,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          }
        }
      );

      // Cards stagger animation
      gsap.fromTo(cards.children,
        { y: 80, rotateX: 10, opacity: 0 },
        {
          y: 0,
          rotateX: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: cards,
            start: 'top 75%',
            end: 'top 45%',
            scrub: 1,
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const formatSalary = (job: typeof featuredJobs[0]) => {
    const { min, max, currency, period } = job.salary;
    const suffix = period === 'year' ? 'k' : '/hr';
    const minVal = period === 'year' ? min / 1000 : min;
    const maxVal = period === 'year' ? max / 1000 : max;
    return `${currency}${minVal}${suffix}–${currency}${maxVal}${suffix}`;
  };

  return (
    <section 
      ref={sectionRef}
      className="relative w-full py-20 lg:py-28 bg-[#F6F8FB] z-20"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Heading */}
        <div ref={headingRef} className="flex flex-col lg:flex-row lg:items-end lg:justify-between mb-12">
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold text-[#0B0F1A]">
              Featured jobs
            </h2>
            <p className="mt-3 text-[#6B7280] max-w-lg">
              Hand-picked roles that match your skills and schedule. Updated daily.
            </p>
          </div>
          <Button 
            onClick={onViewAll}
            variant="ghost" 
            className="mt-4 lg:mt-0 text-[#2F8E92] hover:text-[#267a7e] hover:bg-[#2F8E92]/10 group"
          >
            View all jobs
            <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>

        {/* Job Cards */}
        <div 
          ref={cardsRef}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {featuredJobs.map((job) => {
            const Icon = job.icon;
            return (
              <div 
                key={job.id}
                className="card-modern p-6 hover:-translate-y-2 hover:shadow-[0_24px_60px_rgba(11,15,26,0.15)] transition-all duration-300 cursor-pointer group will-change-transform"
                style={{ perspective: '1000px' }}
              >
                {/* Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-12 h-12 rounded-xl flex items-center justify-center"
                      style={{ backgroundColor: `${job.color}15` }}
                    >
                      <Icon className="w-6 h-6" style={{ color: job.color }} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#0B0F1A] group-hover:text-[#2F8E92] transition-colors">
                        {job.title}
                      </h3>
                      <p className="text-sm text-[#6B7280]">{job.company}</p>
                    </div>
                  </div>
                </div>

                {/* Meta */}
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="secondary" className="bg-gray-100 text-[#6B7280] font-normal">
                    <MapPin className="w-3 h-3 mr-1" />
                    {job.location}
                  </Badge>
                  <Badge variant="secondary" className="bg-gray-100 text-[#6B7280] font-normal">
                    {job.type === 'full-time' ? 'Full-time' : 'Contract'}
                  </Badge>
                </div>

                {/* Description */}
                <p className="text-sm text-[#6B7280] mb-4 line-clamp-2">
                  {job.description}
                </p>

                {/* Footer */}
                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div className="flex items-center text-[#0B0F1A] font-semibold">
                    <DollarSign className="w-4 h-4" />
                    {formatSalary(job)}
                  </div>
                  <span className="text-sm text-[#2F8E92] font-medium group-hover:underline">
                    Apply now
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
