import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Mail, CheckCircle, Loader2 } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export function NewsletterSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;

    if (!section || !content) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(content,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: content,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSubmitting(false);
    setIsSubmitted(true);
    setEmail('');
  };

  return (
    <section 
      ref={sectionRef}
      className="relative w-full py-20 lg:py-28 bg-[#F6F8FB] z-[70]"
    >
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div 
          ref={contentRef}
          className="card-modern p-8 lg:p-12 text-center will-change-transform"
        >
          <div className="w-16 h-16 bg-[#2F8E92]/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Mail className="w-8 h-8 text-[#2F8E92]" />
          </div>
          
          <h2 className="text-2xl lg:text-3xl font-bold text-[#0B0F1A]">
            Get one career move a week
          </h2>
          
          <p className="mt-3 text-[#6B7280] max-w-md mx-auto">
            Jobs, tips, and tools—no noise, unsubscribe anytime.
          </p>

          {isSubmitted ? (
            <div className="mt-8 flex items-center justify-center gap-3 text-green-600">
              <CheckCircle className="w-6 h-6" />
              <span className="font-medium">Thanks for subscribing!</span>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="mt-8 flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <Input
                type="email"
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-14 rounded-xl border-gray-200 focus:border-[#2F8E92] focus:ring-[#2F8E92]"
                required
              />
              <Button 
                type="submit"
                disabled={isSubmitting}
                className="h-14 px-8 btn-primary whitespace-nowrap"
              >
                {isSubmitting ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  'Subscribe'
                )}
              </Button>
            </form>
          )}
          
          <p className="mt-4 text-xs text-[#6B7280]">
            We respect your privacy. No spam, ever.
          </p>
        </div>
      </div>
    </section>
  );
}
