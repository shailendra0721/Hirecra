import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Briefcase, Twitter, Linkedin, Instagram, Mail, MapPin } from 'lucide-react';
import type { View } from '@/App';

gsap.registerPlugin(ScrollTrigger);

interface FooterProps {
  onNavigate: (view: View) => void;
}

const footerLinks = {
  product: [
    { label: 'Jobs', view: 'jobs' as View },
    { label: 'Resume Builder', view: 'resume' as View },
    { label: 'ATS Checker', view: 'ats' as View },
    { label: 'Application Tracker', view: 'tracker' as View },
    { label: 'AI Assistant', view: 'assistant' as View },
  ],
  company: [
    { label: 'About', view: 'home' as View },
    { label: 'Blog', view: 'home' as View },
    { label: 'Careers', view: 'home' as View },
    { label: 'Press', view: 'home' as View },
  ],
  legal: [
    { label: 'Privacy', view: 'home' as View },
    { label: 'Terms', view: 'home' as View },
    { label: 'Cookies', view: 'home' as View },
  ],
};

export function Footer({ onNavigate }: FooterProps) {
  const footerRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const footer = footerRef.current;
    const content = contentRef.current;

    if (!footer || !content) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(content.children,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: content,
            start: 'top 90%',
            toggleActions: 'play none none reverse',
          }
        }
      );
    }, footer);

    return () => ctx.revert();
  }, []);

  return (
    <footer 
      ref={footerRef}
      className="relative w-full bg-[#0B0F1A] text-white z-[100]"
    >
      <div 
        ref={contentRef}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-20"
      >
        <div className="grid lg:grid-cols-5 gap-12 lg:gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <button 
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2 group"
            >
              <div className="w-10 h-10 bg-[#2F8E92] rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform">
                <Briefcase className="w-5 h-5 text-white" />
              </div>
              <span className="font-bold text-xl">HireCraft</span>
            </button>
            
            <p className="mt-4 text-white/60 max-w-sm">
              Find your next move. Build your story. The all-in-one platform for job seekers who want to stand out.
            </p>
            
            <div className="mt-6 space-y-3">
              <a 
                href="mailto:hello@hirecraft.io" 
                className="flex items-center gap-3 text-white/60 hover:text-[#2F8E92] transition-colors"
              >
                <Mail className="w-4 h-4" />
                hello@hirecraft.io
              </a>
              <div className="flex items-center gap-3 text-white/60">
                <MapPin className="w-4 h-4" />
                San Francisco, CA
              </div>
            </div>
          </div>

          {/* Links Columns */}
          <div>
            <h4 className="font-semibold mb-4">Product</h4>
            <ul className="space-y-3">
              {footerLinks.product.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => onNavigate(link.view)}
                    className="text-white/60 hover:text-[#2F8E92] transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => onNavigate(link.view)}
                    className="text-white/60 hover:text-[#2F8E92] transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Legal</h4>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.label}>
                  <button
                    onClick={() => onNavigate(link.view)}
                    className="text-white/60 hover:text-[#2F8E92] transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-white/40 text-sm">
            © 2026 HireCraft. All rights reserved.
          </p>
          
          <div className="flex items-center gap-4">
            <a 
              href="#" 
              className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-[#2F8E92] transition-colors"
            >
              <Twitter className="w-5 h-5" />
            </a>
            <a 
              href="#" 
              className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-[#2F8E92] transition-colors"
            >
              <Linkedin className="w-5 h-5" />
            </a>
            <a 
              href="#" 
              className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-[#2F8E92] transition-colors"
            >
              <Instagram className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
