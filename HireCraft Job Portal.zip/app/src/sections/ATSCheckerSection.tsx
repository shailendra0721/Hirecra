import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle, Target, BarChart3 } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface ATSCheckerSectionProps {
  onCheckResume: () => void;
}

export function ATSCheckerSection({ onCheckResume }: ATSCheckerSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const image = imageRef.current;
    const text = textRef.current;
    const cta = ctaRef.current;

    if (!section || !image || !text || !cta) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0% - 30%)
      scrollTl.fromTo(image,
        { x: '60vw', scale: 0.96, opacity: 0 },
        { x: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );
      
      scrollTl.fromTo(text,
        { x: '-40vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'none' },
        0.05
      );
      
      scrollTl.fromTo(cta,
        { y: '20vh', scale: 0.92, opacity: 0 },
        { y: 0, scale: 1, opacity: 1, ease: 'none' },
        0.1
      );

      // EXIT (70% - 100%)
      scrollTl.fromTo(image,
        { x: 0, y: 0, scale: 1, opacity: 1 },
        { x: '14vw', y: '8vh', scale: 0.94, opacity: 0.25, ease: 'power2.in' },
        0.7
      );
      
      scrollTl.fromTo(text,
        { x: 0, opacity: 1 },
        { x: '-10vw', opacity: 0.2, ease: 'power2.in' },
        0.7
      );
      
      scrollTl.fromTo(cta,
        { y: 0, opacity: 1 },
        { y: '12vh', opacity: 0, ease: 'power2.in' },
        0.75
      );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="relative w-full h-screen bg-[#F6F8FB] overflow-hidden z-40"
    >
      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center w-full">
          {/* Left Content */}
          <div ref={textRef} className="will-change-transform">
            <span className="eyebrow">ATS CHECKER</span>
            
            <h2 className="heading-display text-3xl sm:text-4xl lg:text-5xl text-[#0B0F1A] mt-4">
              PASS THE SCREEN
            </h2>
            <h2 className="heading-display text-3xl sm:text-4xl lg:text-5xl text-[#2F8E92]">
              WITH CONFIDENCE
            </h2>
            
            <p className="mt-6 text-lg text-[#6B7280] max-w-md">
              Get a clear score, keyword suggestions, and fixes tailored to the job—before you apply.
            </p>

            <ul className="mt-8 space-y-4">
              {[
                'Instant ATS compatibility score',
                'Missing keyword detection',
                'Formatting issue alerts',
                'Job-specific optimization tips',
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-[#0B0F1A]">
                  <div className="w-6 h-6 bg-[#2F8E92]/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="w-3 h-3 text-[#2F8E92]" />
                  </div>
                  {item}
                </li>
              ))}
            </ul>

            <div ref={ctaRef} className="mt-10 will-change-transform">
              <Button 
                onClick={onCheckResume}
                className="btn-primary text-base px-8 py-6 h-auto group"
              >
                Check my resume
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Button>
            </div>
          </div>

          {/* Right Image */}
          <div 
            ref={imageRef}
            className="relative will-change-transform"
          >
            <div className="relative rounded-[28px] overflow-hidden shadow-[0_18px_50px_rgba(11,15,26,0.15)] aspect-[4/3]">
              <img 
                src="/ats_laptop_review.jpg" 
                alt="ATS checker"
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Floating stats cards */}
            <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-lg p-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                  <BarChart3 className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-[#0B0F1A]">92%</p>
                  <p className="text-[#6B7280] text-xs">ATS Score</p>
                </div>
              </div>
            </div>
            
            <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-lg p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#2F8E92]/10 rounded-full flex items-center justify-center">
                  <Target className="w-5 h-5 text-[#2F8E92]" />
                </div>
                <div>
                  <p className="text-[#0B0F1A] font-semibold text-sm">Keywords</p>
                  <p className="text-green-600 text-xs">24/27 matched</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
