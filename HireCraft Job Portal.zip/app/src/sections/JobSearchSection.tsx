import { useRef, useLayoutEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, MapPin, Briefcase, Clock, Monitor, Palette, Code, Megaphone } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface JobSearchSectionProps {
  onSearch: () => void;
}

const filterChips = [
  { label: 'Remote', icon: Monitor },
  { label: 'Full-time', icon: Clock },
  { label: 'Contract', icon: Briefcase },
  { label: 'Design', icon: Palette },
  { label: 'Engineering', icon: Code },
  { label: 'Marketing', icon: Megaphone },
];

export function JobSearchSection({ onSearch }: JobSearchSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const chipsRef = useRef<HTMLDivElement>(null);
  const [activeFilters, setActiveFilters] = useState<string[]>([]);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const card = cardRef.current;
    const chips = chipsRef.current;

    if (!section || !card || !chips) return;

    const ctx = gsap.context(() => {
      // Card entrance animation
      gsap.fromTo(card,
        { y: 60, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: card,
            start: 'top 80%',
            end: 'top 55%',
            scrub: 1,
          }
        }
      );

      // Chips stagger animation
      gsap.fromTo(chips.children,
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.5,
          stagger: 0.08,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: chips,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const toggleFilter = (label: string) => {
    setActiveFilters(prev => 
      prev.includes(label) 
        ? prev.filter(f => f !== label)
        : [...prev, label]
    );
  };

  return (
    <section 
      ref={sectionRef}
      className="relative w-full py-20 lg:py-28 bg-[#F6F8FB] z-20"
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title */}
        <div className="text-center mb-8">
          <h2 className="text-2xl lg:text-3xl font-bold text-[#0B0F1A]">
            Search jobs
          </h2>
          <p className="mt-2 text-[#6B7280]">
            Find your perfect role from thousands of opportunities
          </p>
        </div>

        {/* Search Card */}
        <div 
          ref={cardRef}
          className="card-modern p-4 lg:p-6 will-change-transform"
        >
          <div className="flex flex-col lg:flex-row gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
              <Input 
                placeholder="Job title or keyword"
                className="h-14 pl-12 rounded-xl border-gray-200 focus:border-[#2F8E92] focus:ring-[#2F8E92]"
              />
            </div>
            <div className="flex-1 relative">
              <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
              <Input 
                placeholder="City or remote"
                className="h-14 pl-12 rounded-xl border-gray-200 focus:border-[#2F8E92] focus:ring-[#2F8E92]"
              />
            </div>
            <Button 
              onClick={onSearch}
              className="h-14 px-8 btn-primary"
            >
              <Search className="w-5 h-5 lg:mr-2" />
              <span className="hidden lg:inline">Search</span>
            </Button>
          </div>
        </div>

        {/* Filter Chips */}
        <div 
          ref={chipsRef}
          className="mt-6 flex flex-wrap justify-center gap-2"
        >
          {filterChips.map((chip) => {
            const isActive = activeFilters.includes(chip.label);
            const Icon = chip.icon;
            return (
              <button
                key={chip.label}
                onClick={() => toggleFilter(chip.label)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-full text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-[#2F8E92] text-white'
                    : 'bg-white text-[#6B7280] hover:text-[#0B0F1A] hover:bg-gray-50 border border-gray-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                {chip.label}
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}
