import { useRef, useLayoutEffect, useState, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Building2, Briefcase, TrendingUp } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const partners = [
  'Google', 'Microsoft', 'Amazon', 'Meta', 'Apple', 'Netflix'
];

const stats = [
  { id: '1', value: 12000, suffix: '+', label: 'Resumes built', icon: Briefcase },
  { id: '2', value: 48000, suffix: '+', label: 'Applications tracked', icon: TrendingUp },
  { id: '3', value: 180, suffix: '+', label: 'Companies hiring', icon: Building2 },
];

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const counterRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const duration = 2000;
            const steps = 60;
            const increment = value / steps;
            let current = 0;
            const timer = setInterval(() => {
              current += increment;
              if (current >= value) {
                setCount(value);
                clearInterval(timer);
              } else {
                setCount(Math.floor(current));
              }
            }, duration / steps);
            observer.disconnect();
          }
        });
      },
      { threshold: 0.5 }
    );

    if (counterRef.current) {
      observer.observe(counterRef.current);
    }

    return () => observer.disconnect();
  }, [value]);

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return (num / 1000).toFixed(num >= 10000 ? 0 : 1) + 'k';
    }
    return num.toString();
  };

  return (
    <span ref={counterRef}>
      {formatNumber(count)}{suffix}
    </span>
  );
}

export function PartnersSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const logosRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const logos = logosRef.current;
    const statsEl = statsRef.current;

    if (!section || !logos || !statsEl) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(logos.children,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: logos,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          }
        }
      );

      gsap.fromTo(statsEl.children,
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: statsEl,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="relative w-full py-20 lg:py-28 bg-[#F6F8FB] z-[90]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Partner Logos */}
        <div className="text-center mb-12">
          <p className="text-sm text-[#6B7280] uppercase tracking-wider mb-8">
            Trusted by teams and job seekers
          </p>
          <div 
            ref={logosRef}
            className="flex flex-wrap justify-center items-center gap-8 lg:gap-16"
          >
            {partners.map((partner) => (
              <div 
                key={partner}
                className="text-2xl lg:text-3xl font-bold text-gray-300 hover:text-[#0B0F1A] transition-colors cursor-default"
              >
                {partner}
              </div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div 
          ref={statsRef}
          className="grid md:grid-cols-3 gap-8 mt-16 pt-16 border-t border-gray-200"
        >
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <div key={stat.id} className="text-center">
                <div className="w-12 h-12 bg-[#2F8E92]/10 rounded-xl flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-6 h-6 text-[#2F8E92]" />
                </div>
                <p className="text-4xl lg:text-5xl font-bold text-[#0B0F1A]">
                  <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                </p>
                <p className="mt-2 text-[#6B7280]">{stat.label}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
