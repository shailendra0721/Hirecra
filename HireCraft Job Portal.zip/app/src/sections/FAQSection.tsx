import { useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

gsap.registerPlugin(ScrollTrigger);

const faqs = [
  {
    id: '1',
    question: 'Is HireCraft free to use?',
    answer: 'Yes! HireCraft offers a free plan that includes saving up to 10 jobs, building 1 resume, and basic ATS scanning. For unlimited resumes, advanced ATS analysis, and AI coaching, check out our Pro plan.',
  },
  {
    id: '2',
    question: 'How does the ATS checker work?',
    answer: 'Our ATS checker analyzes your resume against job descriptions to identify missing keywords, formatting issues, and readability problems. You get a clear score and actionable suggestions to improve your chances of passing automated screening.',
  },
  {
    id: '3',
    question: 'Can I export my resume to PDF?',
    answer: 'Absolutely! All resumes created with HireCraft can be exported to ATS-friendly PDF format with one click. Our templates are designed to be parsed correctly by applicant tracking systems.',
  },
  {
    id: '4',
    question: 'Is my data private?',
    answer: 'Your privacy is our priority. We use industry-standard encryption, never sell your data, and you can delete your account and all associated data at any time. See our Privacy Policy for full details.',
  },
  {
    id: '5',
    question: "What's included in Pro?",
    answer: 'Pro includes unlimited resumes, advanced ATS analysis with keyword matching, AI career coaching, mock interviews, full application tracking, salary insights, and priority support.',
  },
  {
    id: '6',
    question: 'How do I get support?',
    answer: 'Free users can access our help center and community forum. Pro users get priority email support with 24-hour response times. Teams customers receive dedicated support with a dedicated account manager.',
  },
];

export function FAQSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const content = contentRef.current;

    if (!section || !content) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(content,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: content,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section 
      ref={sectionRef}
      className="relative w-full py-20 lg:py-28 bg-[#F6F8FB] z-[70]"
    >
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={contentRef} className="will-change-transform">
          <h2 className="text-3xl lg:text-4xl font-bold text-[#0B0F1A] text-center mb-12">
            Frequently asked questions
          </h2>

          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq) => (
              <AccordionItem 
                key={faq.id} 
                value={faq.id}
                className="card-modern border-none px-6 data-[state=open]:shadow-[0_24px_60px_rgba(11,15,26,0.10)]"
              >
                <AccordionTrigger className="text-left font-semibold text-[#0B0F1A] hover:no-underline py-5">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-[#6B7280] pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
