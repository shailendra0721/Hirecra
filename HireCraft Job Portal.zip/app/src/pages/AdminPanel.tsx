import { useState } from 'react';
import { 
  Users, 
  Briefcase, 
  BarChart3, 
  Settings, 
  Plus, 
  Search, 
  Edit,
  Trash2,
  TrendingUp,
  DollarSign,
  Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { User, Job } from '@/types';

interface AdminPanelProps {
  user: User;
}

const mockUsers: User[] = [
  { id: '1', email: 'john@example.com', name: 'John Doe', role: 'user', createdAt: new Date() },
  { id: '2', email: 'jane@example.com', name: 'Jane Smith', role: 'user', createdAt: new Date() },
  { id: '3', email: 'admin@hirecraft.io', name: 'Admin User', role: 'admin', createdAt: new Date() },
];

const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Senior Product Designer',
    company: 'Figma',
    location: 'Remote',
    type: 'full-time',
    salary: { min: 140000, max: 180000, currency: '$', period: 'year' },
    description: 'Join our design team...',
    requirements: ['5+ years experience'],
    benefits: ['Health insurance'],
    postedAt: new Date(),
    category: 'Design',
  },
  {
    id: '2',
    title: 'Frontend Engineer',
    company: 'Vercel',
    location: 'New York, NY',
    type: 'full-time',
    salary: { min: 130000, max: 170000, currency: '$', period: 'year' },
    description: 'Build the future of web...',
    requirements: ['React experience'],
    benefits: ['Remote-friendly'],
    postedAt: new Date(),
    category: 'Engineering',
  },
];

export function AdminPanel({ user }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [users, setUsers] = useState(mockUsers);
  const [jobs, setJobs] = useState(mockJobs);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingJob, setEditingJob] = useState<Job | null>(null);
  const [isJobDialogOpen, setIsJobDialogOpen] = useState(false);

  const stats = {
    totalUsers: users.length,
    totalJobs: jobs.length,
    activeApplications: 156,
    revenue: 12450,
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredJobs = jobs.filter(j =>
    j.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    j.company.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const deleteUser = (userId: string) => {
    setUsers(prev => prev.filter(u => u.id !== userId));
  };

  const deleteJob = (jobId: string) => {
    setJobs(prev => prev.filter(j => j.id !== jobId));
  };

  const saveJob = (job: Partial<Job>) => {
    if (editingJob) {
      setJobs(prev => prev.map(j => j.id === editingJob.id ? { ...j, ...job } as Job : j));
    } else {
      const newJob: Job = {
        ...job as Job,
        id: Math.random().toString(36).substr(2, 9),
        postedAt: new Date(),
        requirements: [],
        benefits: [],
      };
      setJobs(prev => [...prev, newJob]);
    }
    setIsJobDialogOpen(false);
    setEditingJob(null);
  };

  return (
    <div className="min-h-screen bg-[#F6F8FB] pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-[#0B0F1A]">Admin Panel</h1>
            <p className="mt-2 text-[#6B7280]">Manage users, jobs, and platform settings</p>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#2F8E92] rounded-full flex items-center justify-center">
              <span className="text-white font-semibold">{user.name.charAt(0)}</span>
            </div>
            <div>
              <p className="font-medium text-[#0B0F1A]">{user.name}</p>
              <p className="text-sm text-[#6B7280]">Administrator</p>
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 max-w-md mb-8">
            <TabsTrigger value="dashboard">
              <BarChart3 className="w-4 h-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="users">
              <Users className="w-4 h-4 mr-2" />
              Users
            </TabsTrigger>
            <TabsTrigger value="jobs">
              <Briefcase className="w-4 h-4 mr-2" />
              Jobs
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>

          {/* Dashboard */}
          <TabsContent value="dashboard">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <Card className="card-modern border-none">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-[#6B7280]">Total Users</p>
                      <p className="text-3xl font-bold text-[#0B0F1A]">{stats.totalUsers}</p>
                    </div>
                    <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                      <Users className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="card-modern border-none">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-[#6B7280]">Active Jobs</p>
                      <p className="text-3xl font-bold text-[#0B0F1A]">{stats.totalJobs}</p>
                    </div>
                    <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                      <Briefcase className="w-6 h-6 text-green-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="card-modern border-none">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-[#6B7280]">Applications</p>
                      <p className="text-3xl font-bold text-[#0B0F1A]">{stats.activeApplications}</p>
                    </div>
                    <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-purple-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="card-modern border-none">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-[#6B7280]">Revenue</p>
                      <p className="text-3xl font-bold text-[#0B0F1A]">${stats.revenue}</p>
                    </div>
                    <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
                      <DollarSign className="w-6 h-6 text-amber-600" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card className="card-modern border-none">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { action: 'New user registered', user: 'alice@example.com', time: '2 min ago' },
                    { action: 'Job posted', user: 'Figma - Product Designer', time: '15 min ago' },
                    { action: 'Pro subscription', user: 'bob@example.com', time: '1 hour ago' },
                    { action: 'Application submitted', user: 'charlie@example.com', time: '2 hours ago' },
                  ].map((activity, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-[#0B0F1A]">{activity.action}</p>
                        <p className="text-sm text-[#6B7280]">{activity.user}</p>
                      </div>
                      <span className="text-sm text-[#6B7280]">{activity.time}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users */}
          <TabsContent value="users">
            <Card className="card-modern border-none">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>User Management</CardTitle>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6B7280]" />
                  <Input 
                    placeholder="Search users..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-100">
                        <th className="text-left py-3 px-4 font-medium text-[#6B7280]">User</th>
                        <th className="text-left py-3 px-4 font-medium text-[#6B7280]">Role</th>
                        <th className="text-left py-3 px-4 font-medium text-[#6B7280]">Joined</th>
                        <th className="text-right py-3 px-4 font-medium text-[#6B7280]">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredUsers.map((u) => (
                        <tr key={u.id} className="border-b border-gray-50 hover:bg-gray-50">
                          <td className="py-4 px-4">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-[#2F8E92]/10 rounded-full flex items-center justify-center">
                                <span className="text-[#2F8E92] font-semibold">{u.name.charAt(0)}</span>
                              </div>
                              <div>
                                <p className="font-medium text-[#0B0F1A]">{u.name}</p>
                                <p className="text-sm text-[#6B7280]">{u.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-4 px-4">
                            <Badge className={u.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}>
                              {u.role}
                            </Badge>
                          </td>
                          <td className="py-4 px-4 text-[#6B7280]">
                            {u.createdAt.toLocaleDateString()}
                          </td>
                          <td className="py-4 px-4 text-right">
                            <Button variant="ghost" size="icon">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => deleteUser(u.id)}
                              className="text-red-500"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Jobs */}
          <TabsContent value="jobs">
            <Card className="card-modern border-none">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Job Management</CardTitle>
                <div className="flex gap-3">
                  <div className="relative w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6B7280]" />
                    <Input 
                      placeholder="Search jobs..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Dialog open={isJobDialogOpen} onOpenChange={setIsJobDialogOpen}>
                    <DialogTrigger asChild>
                      <Button className="btn-primary">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Job
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-lg">
                      <DialogHeader>
                        <DialogTitle>{editingJob ? 'Edit Job' : 'Add New Job'}</DialogTitle>
                      </DialogHeader>
                      <JobForm 
                        job={editingJob} 
                        onSave={saveJob} 
                        onCancel={() => {
                          setIsJobDialogOpen(false);
                          setEditingJob(null);
                        }}
                      />
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-100">
                        <th className="text-left py-3 px-4 font-medium text-[#6B7280]">Job</th>
                        <th className="text-left py-3 px-4 font-medium text-[#6B7280]">Location</th>
                        <th className="text-left py-3 px-4 font-medium text-[#6B7280]">Type</th>
                        <th className="text-right py-3 px-4 font-medium text-[#6B7280]">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredJobs.map((job) => (
                        <tr key={job.id} className="border-b border-gray-50 hover:bg-gray-50">
                          <td className="py-4 px-4">
                            <div>
                              <p className="font-medium text-[#0B0F1A]">{job.title}</p>
                              <p className="text-sm text-[#6B7280]">{job.company}</p>
                            </div>
                          </td>
                          <td className="py-4 px-4 text-[#6B7280]">{job.location}</td>
                          <td className="py-4 px-4">
                            <Badge variant="secondary">{job.type}</Badge>
                          </td>
                          <td className="py-4 px-4 text-right">
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => {
                                setEditingJob(job);
                                setIsJobDialogOpen(true);
                              }}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => deleteJob(job.id)}
                              className="text-red-500"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings */}
          <TabsContent value="settings">
            <Card className="card-modern border-none">
              <CardHeader>
                <CardTitle>Platform Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div>
                    <p className="font-medium text-[#0B0F1A]">User Registration</p>
                    <p className="text-sm text-[#6B7280]">Allow new users to sign up</p>
                  </div>
                  <Button variant="outline">Enabled</Button>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div>
                    <p className="font-medium text-[#0B0F1A]">Job Posting</p>
                    <p className="text-sm text-[#6B7280]">Allow companies to post jobs</p>
                  </div>
                  <Button variant="outline">Enabled</Button>
                </div>
                
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                  <div>
                    <p className="font-medium text-[#0B0F1A]">Email Notifications</p>
                    <p className="text-sm text-[#6B7280]">Send email updates to users</p>
                  </div>
                  <Button variant="outline">Enabled</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Job Form Component
function JobForm({ job, onSave, onCancel }: { 
  job: Job | null; 
  onSave: (job: Partial<Job>) => void;
  onCancel: () => void;
}) {
  const [formData, setFormData] = useState<Partial<Job>>(job || {
    title: '',
    company: '',
    location: '',
    type: 'full-time',
    description: '',
    salary: { min: 0, max: 0, currency: '$', period: 'year' },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 mt-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Job Title</Label>
          <Input 
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="e.g., Product Designer"
          />
        </div>
        <div className="space-y-2">
          <Label>Company</Label>
          <Input 
            value={formData.company}
            onChange={(e) => setFormData({ ...formData, company: e.target.value })}
            placeholder="e.g., Figma"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Location</Label>
          <Input 
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            placeholder="e.g., Remote"
          />
        </div>
        <div className="space-y-2">
          <Label>Job Type</Label>
          <Select 
            value={formData.type} 
            onValueChange={(v) => setFormData({ ...formData, type: v as Job['type'] })}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="full-time">Full-time</SelectItem>
              <SelectItem value="part-time">Part-time</SelectItem>
              <SelectItem value="contract">Contract</SelectItem>
              <SelectItem value="remote">Remote</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="space-y-2">
        <Label>Description</Label>
        <Textarea 
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Job description..."
          rows={4}
        />
      </div>
      
      <div className="flex gap-3 justify-end">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" className="btn-primary">
          {job ? 'Save Changes' : 'Create Job'}
        </Button>
      </div>
    </form>
  );
}
