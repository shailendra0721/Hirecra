import { useState } from 'react';
import { 
  Briefcase, 
  FileText, 
  CheckCircle, 
  TrendingUp, 
  ArrowRight,
  Calendar,
  Bell,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import type { User } from '@/types';
import type { View } from '@/App';

interface DashboardProps {
  user: User;
  onNavigate: (view: View) => void;
}

const recentApplications = [
  { id: '1', company: 'Stripe', role: 'Senior Frontend Engineer', status: 'interview', date: '2 days ago' },
  { id: '2', company: 'Notion', role: 'Product Designer', status: 'applied', date: '5 days ago' },
  { id: '3', company: 'Figma', role: 'Design Engineer', status: 'screening', date: '1 week ago' },
];

const upcomingEvents = [
  { id: '1', title: 'Interview with Stripe', date: 'Today, 2:00 PM', type: 'interview' },
  { id: '2', title: 'Resume review deadline', date: 'Tomorrow', type: 'deadline' },
];

export function Dashboard({ user, onNavigate }: DashboardProps) {
  const [stats] = useState({
    applications: 12,
    interviews: 3,
    offers: 1,
    atsScore: 87,
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'applied': return 'bg-blue-100 text-blue-700';
      case 'screening': return 'bg-amber-100 text-amber-700';
      case 'interview': return 'bg-purple-100 text-purple-700';
      case 'offer': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-[#F6F8FB] pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#0B0F1A]">
            Welcome back, {user.name.split(' ')[0]}!
          </h1>
          <p className="mt-2 text-[#6B7280]">
            Here's what's happening with your job search.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="card-modern border-none">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[#6B7280]">Applications</p>
                  <p className="text-3xl font-bold text-[#0B0F1A]">{stats.applications}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <Briefcase className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="card-modern border-none">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[#6B7280]">Interviews</p>
                  <p className="text-3xl font-bold text-[#0B0F1A]">{stats.interviews}</p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="card-modern border-none">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[#6B7280]">Offers</p>
                  <p className="text-3xl font-bold text-[#0B0F1A]">{stats.offers}</p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="card-modern border-none">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[#6B7280]">ATS Score</p>
                  <p className="text-3xl font-bold text-[#0B0F1A]">{stats.atsScore}%</p>
                </div>
                <div className="w-12 h-12 bg-[#2F8E92]/10 rounded-xl flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-[#2F8E92]" />
                </div>
              </div>
              <Progress value={stats.atsScore} className="mt-3 h-2" />
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Applications */}
          <div className="lg:col-span-2">
            <Card className="card-modern border-none">
              <CardHeader className="flex flex-row items-center justify-between pb-4">
                <CardTitle className="text-lg font-semibold">Recent Applications</CardTitle>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => onNavigate('tracker')}
                  className="text-[#2F8E92]"
                >
                  View all
                  <ArrowRight className="ml-1 w-4 h-4" />
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentApplications.map((app) => (
                    <div 
                      key={app.id}
                      className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center shadow-sm">
                          <Briefcase className="w-5 h-5 text-[#2F8E92]" />
                        </div>
                        <div>
                          <p className="font-medium text-[#0B0F1A]">{app.role}</p>
                          <p className="text-sm text-[#6B7280]">{app.company}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <Badge className={getStatusColor(app.status)}>
                          {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                        </Badge>
                        <span className="text-sm text-[#6B7280] hidden sm:block">{app.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Upcoming Events */}
            <Card className="card-modern border-none">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Bell className="w-5 h-5 text-[#2F8E92]" />
                  Upcoming
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {upcomingEvents.map((event) => (
                    <div 
                      key={event.id}
                      className="flex items-start gap-3 p-3 bg-gray-50 rounded-xl"
                    >
                      <div className={`w-2 h-2 rounded-full mt-2 ${
                        event.type === 'interview' ? 'bg-purple-500' : 'bg-amber-500'
                      }`} />
                      <div>
                        <p className="font-medium text-[#0B0F1A] text-sm">{event.title}</p>
                        <p className="text-xs text-[#6B7280]">{event.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="card-modern border-none">
              <CardHeader className="pb-4">
                <CardTitle className="text-lg font-semibold">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button 
                    variant="outline" 
                    className="w-full justify-between"
                    onClick={() => onNavigate('resume')}
                  >
                    <span className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Update resume
                    </span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-between"
                    onClick={() => onNavigate('ats')}
                  >
                    <span className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4" />
                      Check ATS score
                    </span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-between"
                    onClick={() => onNavigate('jobs')}
                  >
                    <span className="flex items-center gap-2">
                      <Briefcase className="w-4 h-4" />
                      Browse jobs
                    </span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
