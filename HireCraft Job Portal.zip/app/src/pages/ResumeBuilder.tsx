import { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Eye, 
  Download, 
  Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import type { User, Resume, Experience, Education } from '@/types';

interface ResumeBuilderProps {
  user: User;
}

const templates = [
  { id: 'modern', name: 'Modern', color: '#2F8E92' },
  { id: 'classic', name: 'Classic', color: '#0B0F1A' },
  { id: 'creative', name: 'Creative', color: '#7C3AED' },
];

export function ResumeBuilder({ user }: ResumeBuilderProps) {
  const [activeTemplate, setActiveTemplate] = useState('modern');
  const [showPreview, setShowPreview] = useState(false);
  const [activeSection, setActiveSection] = useState('personal');
  
  const [resume, setResume] = useState<Partial<Resume>>({
    template: 'modern',
    content: {
      personalInfo: {
        fullName: user.name,
        email: user.email,
        phone: '',
        location: '',
        linkedin: '',
        website: '',
      },
      summary: '',
      experience: [],
      education: [],
      skills: [],
    }
  });

  const [newSkill, setNewSkill] = useState('');

  const updatePersonalInfo = (field: string, value: string) => {
    setResume(prev => ({
      ...prev,
      content: {
        ...prev.content!,
        personalInfo: {
          ...prev.content!.personalInfo,
          [field]: value
        }
      }
    }));
  };

  const addExperience = () => {
    const newExp: Experience = {
      id: Math.random().toString(36).substr(2, 9),
      company: '',
      title: '',
      location: '',
      startDate: '',
      endDate: '',
      current: false,
      description: '',
      achievements: [],
    };
    setResume(prev => ({
      ...prev,
      content: {
        ...prev.content!,
        experience: [...(prev.content?.experience || []), newExp]
      }
    }));
  };

  const updateExperience = (id: string, field: keyof Experience, value: any) => {
    setResume(prev => ({
      ...prev,
      content: {
        ...prev.content!,
        experience: prev.content?.experience.map(exp => 
          exp.id === id ? { ...exp, [field]: value } : exp
        ) || []
      }
    }));
  };

  const removeExperience = (id: string) => {
    setResume(prev => ({
      ...prev,
      content: {
        ...prev.content!,
        experience: prev.content?.experience.filter(exp => exp.id !== id) || []
      }
    }));
  };

  const addEducation = () => {
    const newEdu: Education = {
      id: Math.random().toString(36).substr(2, 9),
      institution: '',
      degree: '',
      field: '',
      location: '',
      startDate: '',
      endDate: '',
      current: false,
    };
    setResume(prev => ({
      ...prev,
      content: {
        ...prev.content!,
        education: [...(prev.content?.education || []), newEdu]
      }
    }));
  };

  const updateEducation = (id: string, field: keyof Education, value: any) => {
    setResume(prev => ({
      ...prev,
      content: {
        ...prev.content!,
        education: prev.content?.education.map(edu => 
          edu.id === id ? { ...edu, [field]: value } : edu
        ) || []
      }
    }));
  };

  const removeEducation = (id: string) => {
    setResume(prev => ({
      ...prev,
      content: {
        ...prev.content!,
        education: prev.content?.education.filter(edu => edu.id !== id) || []
      }
    }));
  };

  const addSkill = () => {
    if (!newSkill.trim()) return;
    setResume(prev => ({
      ...prev,
      content: {
        ...prev.content!,
        skills: [...(prev.content?.skills || []), newSkill.trim()]
      }
    }));
    setNewSkill('');
  };

  const removeSkill = (skill: string) => {
    setResume(prev => ({
      ...prev,
      content: {
        ...prev.content!,
        skills: prev.content?.skills.filter(s => s !== skill) || []
      }
    }));
  };

  const generateSummary = () => {
    const summary = `Results-driven professional with expertise in ${resume.content?.skills.slice(0, 3).join(', ') || 'various areas'}. Proven track record of delivering impactful results and driving innovation. Seeking opportunities to leverage skills and contribute to organizational success.`;
    setResume(prev => ({
      ...prev,
      content: {
        ...prev.content!,
        summary
      }
    }));
  };

  return (
    <div className="min-h-screen bg-[#F6F8FB] pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-[#0B0F1A]">Resume Builder</h1>
            <p className="mt-2 text-[#6B7280]">Create a professional resume that stands out</p>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setShowPreview(true)}>
              <Eye className="w-4 h-4 mr-2" />
              Preview
            </Button>
            <Button className="btn-primary">
              <Download className="w-4 h-4 mr-2" />
              Export PDF
            </Button>
          </div>
        </div>

        {/* Template Selection */}
        <Card className="card-modern border-none mb-6">
          <CardContent className="p-4">
            <p className="text-sm font-medium text-[#6B7280] mb-3">Choose a template</p>
            <div className="flex gap-3">
              {templates.map((template) => (
                <button
                  key={template.id}
                  onClick={() => setActiveTemplate(template.id)}
                  className={`flex-1 p-4 rounded-xl border-2 transition-all ${
                    activeTemplate === template.id
                      ? 'border-[#2F8E92] bg-[#2F8E92]/5'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <div 
                    className="w-full h-20 rounded-lg mb-2"
                    style={{ backgroundColor: `${template.color}15` }}
                  />
                  <p className="font-medium text-[#0B0F1A]">{template.name}</p>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Form Sections */}
          <div className="lg:col-span-2 space-y-6">
            <Tabs value={activeSection} onValueChange={setActiveSection}>
              <TabsList className="grid grid-cols-4 w-full">
                <TabsTrigger value="personal">Personal</TabsTrigger>
                <TabsTrigger value="experience">Experience</TabsTrigger>
                <TabsTrigger value="education">Education</TabsTrigger>
                <TabsTrigger value="skills">Skills</TabsTrigger>
              </TabsList>

              {/* Personal Info */}
              <TabsContent value="personal" className="mt-6">
                <Card className="card-modern border-none">
                  <CardContent className="p-6 space-y-4">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Full name</Label>
                        <Input 
                          value={resume.content?.personalInfo.fullName}
                          onChange={(e) => updatePersonalInfo('fullName', e.target.value)}
                          placeholder="John Doe"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Email</Label>
                        <Input 
                          value={resume.content?.personalInfo.email}
                          onChange={(e) => updatePersonalInfo('email', e.target.value)}
                          placeholder="john@example.com"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Phone</Label>
                        <Input 
                          value={resume.content?.personalInfo.phone}
                          onChange={(e) => updatePersonalInfo('phone', e.target.value)}
                          placeholder="+1 (555) 123-4567"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Location</Label>
                        <Input 
                          value={resume.content?.personalInfo.location}
                          onChange={(e) => updatePersonalInfo('location', e.target.value)}
                          placeholder="San Francisco, CA"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>LinkedIn</Label>
                        <Input 
                          value={resume.content?.personalInfo.linkedin}
                          onChange={(e) => updatePersonalInfo('linkedin', e.target.value)}
                          placeholder="linkedin.com/in/johndoe"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Website</Label>
                        <Input 
                          value={resume.content?.personalInfo.website}
                          onChange={(e) => updatePersonalInfo('website', e.target.value)}
                          placeholder="johndoe.com"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>Professional Summary</Label>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={generateSummary}
                          className="text-[#2F8E92]"
                        >
                          <Sparkles className="w-4 h-4 mr-1" />
                          AI Generate
                        </Button>
                      </div>
                      <Textarea 
                        value={resume.content?.summary}
                        onChange={(e) => setResume(prev => ({
                          ...prev,
                          content: { ...prev.content!, summary: e.target.value }
                        }))}
                        placeholder="Write a brief summary of your professional background and goals..."
                        rows={4}
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Experience */}
              <TabsContent value="experience" className="mt-6">
                <Card className="card-modern border-none">
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      {resume.content?.experience.map((exp, index) => (
                        <div key={exp.id} className="p-4 bg-gray-50 rounded-xl">
                          <div className="flex items-center justify-between mb-4">
                            <span className="text-sm font-medium text-[#6B7280]">Experience {index + 1}</span>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => removeExperience(exp.id)}
                              className="text-red-500 hover:text-red-600"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          <div className="grid sm:grid-cols-2 gap-4">
                            <Input 
                              placeholder="Job title"
                              value={exp.title}
                              onChange={(e) => updateExperience(exp.id, 'title', e.target.value)}
                            />
                            <Input 
                              placeholder="Company"
                              value={exp.company}
                              onChange={(e) => updateExperience(exp.id, 'company', e.target.value)}
                            />
                            <Input 
                              placeholder="Location"
                              value={exp.location}
                              onChange={(e) => updateExperience(exp.id, 'location', e.target.value)}
                            />
                            <div className="flex gap-2">
                              <Input 
                                placeholder="Start date"
                                value={exp.startDate}
                                onChange={(e) => updateExperience(exp.id, 'startDate', e.target.value)}
                              />
                              <Input 
                                placeholder="End date"
                                value={exp.endDate}
                                onChange={(e) => updateExperience(exp.id, 'endDate', e.target.value)}
                              />
                            </div>
                            <Textarea 
                              placeholder="Description"
                              value={exp.description}
                              onChange={(e) => updateExperience(exp.id, 'description', e.target.value)}
                              className="sm:col-span-2"
                              rows={3}
                            />
                          </div>
                        </div>
                      ))}
                      
                      <Button 
                        variant="outline" 
                        onClick={addExperience}
                        className="w-full"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Experience
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Education */}
              <TabsContent value="education" className="mt-6">
                <Card className="card-modern border-none">
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      {resume.content?.education.map((edu, index) => (
                        <div key={edu.id} className="p-4 bg-gray-50 rounded-xl">
                          <div className="flex items-center justify-between mb-4">
                            <span className="text-sm font-medium text-[#6B7280]">Education {index + 1}</span>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => removeEducation(edu.id)}
                              className="text-red-500 hover:text-red-600"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                          <div className="grid sm:grid-cols-2 gap-4">
                            <Input 
                              placeholder="Institution"
                              value={edu.institution}
                              onChange={(e) => updateEducation(edu.id, 'institution', e.target.value)}
                            />
                            <Input 
                              placeholder="Degree"
                              value={edu.degree}
                              onChange={(e) => updateEducation(edu.id, 'degree', e.target.value)}
                            />
                            <Input 
                              placeholder="Field of study"
                              value={edu.field}
                              onChange={(e) => updateEducation(edu.id, 'field', e.target.value)}
                            />
                            <Input 
                              placeholder="Location"
                              value={edu.location}
                              onChange={(e) => updateEducation(edu.id, 'location', e.target.value)}
                            />
                            <div className="flex gap-2">
                              <Input 
                                placeholder="Start date"
                                value={edu.startDate}
                                onChange={(e) => updateEducation(edu.id, 'startDate', e.target.value)}
                              />
                              <Input 
                                placeholder="End date"
                                value={edu.endDate}
                                onChange={(e) => updateEducation(edu.id, 'endDate', e.target.value)}
                              />
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      <Button 
                        variant="outline" 
                        onClick={addEducation}
                        className="w-full"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Add Education
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Skills */}
              <TabsContent value="skills" className="mt-6">
                <Card className="card-modern border-none">
                  <CardContent className="p-6">
                    <div className="space-y-4">
                      <div className="flex gap-2">
                        <Input 
                          placeholder="Add a skill (e.g., React, Python, Project Management)"
                          value={newSkill}
                          onChange={(e) => setNewSkill(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && addSkill()}
                        />
                        <Button onClick={addSkill}>
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        {resume.content?.skills.map((skill) => (
                          <Badge 
                            key={skill}
                            variant="secondary"
                            className="px-3 py-2 text-sm cursor-pointer hover:bg-red-100"
                            onClick={() => removeSkill(skill)}
                          >
                            {skill}
                            <Trash2 className="w-3 h-3 ml-2" />
                          </Badge>
                        ))}
                      </div>
                      
                      {resume.content?.skills.length === 0 && (
                        <p className="text-center text-[#6B7280] py-8">
                          No skills added yet. Start typing to add your skills.
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Preview Panel */}
          <div className="hidden lg:block">
            <Card className="card-modern border-none sticky top-24">
              <CardContent className="p-6">
                <p className="text-sm font-medium text-[#6B7280] mb-4">Live Preview</p>
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 max-h-[600px] overflow-y-auto">
                  {/* Mini Resume Preview */}
                  <div className="text-center mb-4">
                    <h3 className="text-xl font-bold text-[#0B0F1A]">
                      {resume.content?.personalInfo.fullName || 'Your Name'}
                    </h3>
                    <p className="text-sm text-[#6B7280]">
                      {resume.content?.personalInfo.location}
                      {resume.content?.personalInfo.location && resume.content?.personalInfo.email && ' • '}
                      {resume.content?.personalInfo.email}
                    </p>
                  </div>
                  
                  {resume.content?.summary && (
                    <div className="mb-4">
                      <h4 className="text-xs font-bold uppercase text-[#6B7280] mb-1">Summary</h4>
                      <p className="text-xs text-[#0B0F1A]">{resume.content.summary}</p>
                    </div>
                  )}
                  
                  {resume.content?.experience && resume.content.experience.length > 0 && (
                    <div className="mb-4">
                      <h4 className="text-xs font-bold uppercase text-[#6B7280] mb-1">Experience</h4>
                      {resume.content.experience.slice(0, 2).map((exp) => (
                        <div key={exp.id} className="mb-2">
                          <p className="text-xs font-semibold">{exp.title}</p>
                          <p className="text-xs text-[#6B7280]">{exp.company}</p>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {resume.content?.skills && resume.content.skills.length > 0 && (
                    <div>
                      <h4 className="text-xs font-bold uppercase text-[#6B7280] mb-1">Skills</h4>
                      <p className="text-xs text-[#0B0F1A]">
                        {resume.content.skills.slice(0, 8).join(' • ')}
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Full Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Resume Preview</DialogTitle>
          </DialogHeader>
          <div className="bg-white p-8 shadow-lg">
            {/* Full resume preview would go here */}
            <div className="text-center">
              <h2 className="text-2xl font-bold">{resume.content?.personalInfo.fullName}</h2>
              <p className="text-[#6B7280]">Preview mode - Export to see full resume</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
