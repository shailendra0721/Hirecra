import { useState } from 'react';
import { 
  Search, 
  MapPin, 
  DollarSign, 
  Briefcase, 
  Clock, 
  Bookmark,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { User, Job } from '@/types';

interface JobsPageProps {
  user: User | null;
  onLogin: () => void;
}

const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Senior Product Designer',
    company: 'Figma',
    companyLogo: '/figma.svg',
    location: 'Remote',
    type: 'full-time',
    salary: { min: 140000, max: 180000, currency: '$', period: 'year' },
    description: 'Join our design team to shape the future of collaborative design tools. You will work on complex problems that impact millions of creators worldwide.',
    requirements: ['5+ years of product design experience', 'Proficiency in Figma', 'Strong portfolio'],
    benefits: ['Health insurance', 'Unlimited PTO', 'Home office stipend'],
    postedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    category: 'Design',
  },
  {
    id: '2',
    title: 'Frontend Engineer',
    company: 'Vercel',
    companyLogo: '/vercel.svg',
    location: 'New York, NY',
    type: 'full-time',
    salary: { min: 130000, max: 170000, currency: '$', period: 'year' },
    description: 'Build the future of the web with Next.js. Were looking for engineers who are passionate about performance and developer experience.',
    requirements: ['3+ years with React', 'Experience with Next.js', 'TypeScript proficiency'],
    benefits: ['Competitive salary', 'Equity', 'Remote-friendly'],
    postedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    category: 'Engineering',
  },
  {
    id: '3',
    title: 'Content Strategist',
    company: 'Notion',
    companyLogo: '/notion.svg',
    location: 'San Francisco, CA',
    type: 'remote',
    salary: { min: 100000, max: 140000, currency: '$', period: 'year' },
    description: 'Help teams work better together through clear, compelling content. You will shape the voice of Notion across all touchpoints.',
    requirements: ['3+ years in content strategy', 'Excellent writing skills', 'B2B SaaS experience'],
    benefits: ['401k match', 'Wellness stipend', 'Learning budget'],
    postedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    category: 'Marketing',
  },
  {
    id: '4',
    title: 'Full Stack Developer',
    company: 'Stripe',
    companyLogo: '/stripe.svg',
    location: 'Remote',
    type: 'full-time',
    salary: { min: 150000, max: 200000, currency: '$', period: 'year' },
    description: 'Work on the infrastructure that powers internet commerce. Build systems that process billions of dollars annually.',
    requirements: ['5+ years of experience', 'Ruby or Go proficiency', 'Distributed systems knowledge'],
    benefits: ['Top-tier compensation', 'Generous parental leave', 'Annual retreat'],
    postedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    category: 'Engineering',
  },
  {
    id: '5',
    title: 'UX Researcher',
    company: 'Airbnb',
    companyLogo: '/airbnb.svg',
    location: 'San Francisco, CA',
    type: 'hybrid',
    salary: { min: 120000, max: 160000, currency: '$', period: 'year' },
    description: 'Uncover insights that shape the future of travel. Conduct research that informs product decisions across the company.',
    requirements: ['3+ years in UX research', 'Mixed methods expertise', 'Strong storytelling skills'],
    benefits: ['Travel credits', 'Health & wellness', 'Flexible schedule'],
    postedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    category: 'Design',
  },
  {
    id: '6',
    title: 'Marketing Manager',
    company: 'Linear',
    companyLogo: '/linear.svg',
    location: 'Remote',
    type: 'full-time',
    salary: { min: 110000, max: 150000, currency: '$', period: 'year' },
    description: 'Drive growth for the next generation of software development tools. Build campaigns that resonate with developers.',
    requirements: ['4+ years in B2B marketing', 'Developer tools experience', 'Data-driven mindset'],
    benefits: ['Equity', 'Remote-first', 'Professional development'],
    postedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
    category: 'Marketing',
  },
];

export function JobsPage({ user, onLogin }: JobsPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [locationFilter, setLocationFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [savedJobs, setSavedJobs] = useState<string[]>([]);

  const filteredJobs = mockJobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         job.company.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLocation = locationFilter === 'all' || job.location.toLowerCase().includes(locationFilter.toLowerCase());
    const matchesType = typeFilter === 'all' || job.type === typeFilter;
    return matchesSearch && matchesLocation && matchesType;
  });

  const toggleSaveJob = (jobId: string) => {
    if (!user) {
      onLogin();
      return;
    }
    setSavedJobs(prev => 
      prev.includes(jobId) 
        ? prev.filter(id => id !== jobId)
        : [...prev, jobId]
    );
  };

  const formatSalary = (job: Job) => {
    const { min, max, currency, period } = job.salary;
    const suffix = period === 'year' ? 'k' : '/hr';
    const minVal = period === 'year' ? min / 1000 : min;
    const maxVal = period === 'year' ? max / 1000 : max;
    return `${currency}${minVal}${suffix}–${currency}${maxVal}${suffix}`;
  };

  const formatDate = (date: Date) => {
    const days = Math.floor((Date.now() - date.getTime()) / (1000 * 60 * 60 * 24));
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    return `${days} days ago`;
  };

  return (
    <div className="min-h-screen bg-[#F6F8FB] pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#0B0F1A]">Find your next role</h1>
          <p className="mt-2 text-[#6B7280]">Browse {mockJobs.length}+ open positions from top companies</p>
        </div>

        {/* Search & Filters */}
        <Card className="card-modern border-none mb-8">
          <CardContent className="p-4 lg:p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
                <Input 
                  placeholder="Search by job title or company"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="h-12 pl-12 rounded-xl"
                />
              </div>
              <div className="flex gap-2">
                <Select value={locationFilter} onValueChange={setLocationFilter}>
                  <SelectTrigger className="h-12 w-[160px] rounded-xl">
                    <MapPin className="w-4 h-4 mr-2" />
                    <SelectValue placeholder="Location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All locations</SelectItem>
                    <SelectItem value="remote">Remote</SelectItem>
                    <SelectItem value="san francisco">San Francisco</SelectItem>
                    <SelectItem value="new york">New York</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="h-12 w-[160px] rounded-xl">
                    <Briefcase className="w-4 h-4 mr-2" />
                    <SelectValue placeholder="Job Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All types</SelectItem>
                    <SelectItem value="full-time">Full-time</SelectItem>
                    <SelectItem value="contract">Contract</SelectItem>
                    <SelectItem value="remote">Remote</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="space-y-4">
          {filteredJobs.map((job) => (
            <Card 
              key={job.id} 
              className="card-modern border-none hover:shadow-[0_24px_60px_rgba(11,15,26,0.10)] transition-shadow cursor-pointer"
              onClick={() => setSelectedJob(job)}
            >
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-[#2F8E92]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Briefcase className="w-6 h-6 text-[#2F8E92]" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-[#0B0F1A] text-lg">{job.title}</h3>
                      <p className="text-[#6B7280]">{job.company}</p>
                      <div className="flex flex-wrap items-center gap-2 mt-2">
                        <Badge variant="secondary" className="bg-gray-100 text-[#6B7280] font-normal">
                          <MapPin className="w-3 h-3 mr-1" />
                          {job.location}
                        </Badge>
                        <Badge variant="secondary" className="bg-gray-100 text-[#6B7280] font-normal">
                          <Briefcase className="w-3 h-3 mr-1" />
                          {job.type}
                        </Badge>
                        <Badge variant="secondary" className="bg-gray-100 text-[#6B7280] font-normal">
                          <DollarSign className="w-3 h-3 mr-1" />
                          {formatSalary(job)}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-[#6B7280] flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {formatDate(job.postedAt)}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSaveJob(job.id);
                      }}
                      className={savedJobs.includes(job.id) ? 'text-[#2F8E92]' : ''}
                    >
                      <Bookmark className={`w-5 h-5 ${savedJobs.includes(job.id) ? 'fill-current' : ''}`} />
                    </Button>
                    <Button className="btn-primary">
                      Apply
                      <ExternalLink className="ml-2 w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredJobs.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-[#6B7280]" />
            </div>
            <h3 className="text-lg font-semibold text-[#0B0F1A]">No jobs found</h3>
            <p className="text-[#6B7280] mt-2">Try adjusting your search or filters</p>
          </div>
        )}
      </div>

      {/* Job Detail Dialog */}
      <Dialog open={!!selectedJob} onOpenChange={() => setSelectedJob(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedJob && (
            <>
              <DialogHeader>
                <div className="flex items-start gap-4">
                  <div className="w-14 h-14 bg-[#2F8E92]/10 rounded-xl flex items-center justify-center">
                    <Briefcase className="w-7 h-7 text-[#2F8E92]" />
                  </div>
                  <div>
                    <DialogTitle className="text-2xl">{selectedJob.title}</DialogTitle>
                    <p className="text-[#6B7280] mt-1">{selectedJob.company}</p>
                    <div className="flex flex-wrap gap-2 mt-3">
                      <Badge variant="secondary">
                        <MapPin className="w-3 h-3 mr-1" />
                        {selectedJob.location}
                      </Badge>
                      <Badge variant="secondary">
                        <Briefcase className="w-3 h-3 mr-1" />
                        {selectedJob.type}
                      </Badge>
                      <Badge variant="secondary">
                        <DollarSign className="w-3 h-3 mr-1" />
                        {formatSalary(selectedJob)}
                      </Badge>
                    </div>
                  </div>
                </div>
              </DialogHeader>
              
              <div className="space-y-6 mt-4">
                <div>
                  <h4 className="font-semibold text-[#0B0F1A] mb-2">About the role</h4>
                  <p className="text-[#6B7280]">{selectedJob.description}</p>
                </div>
                
                <div>
                  <h4 className="font-semibold text-[#0B0F1A] mb-2">Requirements</h4>
                  <ul className="list-disc list-inside text-[#6B7280] space-y-1">
                    {selectedJob.requirements.map((req, i) => (
                      <li key={i}>{req}</li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold text-[#0B0F1A] mb-2">Benefits</h4>
                  <ul className="list-disc list-inside text-[#6B7280] space-y-1">
                    {selectedJob.benefits.map((benefit, i) => (
                      <li key={i}>{benefit}</li>
                    ))}
                  </ul>
                </div>
                
                <div className="flex gap-3 pt-4">
                  <Button className="flex-1 btn-primary">
                    Apply Now
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => toggleSaveJob(selectedJob.id)}
                    className={savedJobs.includes(selectedJob.id) ? 'text-[#2F8E92]' : ''}
                  >
                    <Bookmark className={`w-4 h-4 mr-2 ${savedJobs.includes(selectedJob.id) ? 'fill-current' : ''}`} />
                    Save
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
