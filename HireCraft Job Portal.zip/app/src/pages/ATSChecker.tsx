import { useState } from 'react';
import { 
  Upload, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  XCircle,
  Target,
  BarChart3,
  RefreshCw,
  ArrowRight,
  Lightbulb
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { User, ATSResult } from '@/types';

interface ATSCheckerProps {
  user: User;
}

export function ATSChecker({ }: ATSCheckerProps) {
  const [jobDescription, setJobDescription] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<ATSResult | null>(null);
  const [activeTab, setActiveTab] = useState('upload');

  const analyzeResume = async () => {
    if (!jobDescription.trim()) return;
    
    setIsAnalyzing(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2500));
    
    // Mock result
    const mockResult: ATSResult = {
      score: 78,
      keywords: {
        found: ['React', 'TypeScript', 'Node.js', 'Git', 'Agile', 'REST API'],
        missing: ['GraphQL', 'Docker', 'AWS', 'Kubernetes'],
        suggested: ['cloud platforms', 'microservices', 'CI/CD'],
      },
      formatting: {
        issues: ['Header too large', 'Inconsistent spacing'],
        suggestions: ['Use standard fonts', 'Keep to 1-2 pages', 'Use bullet points'],
      },
      readability: {
        score: 85,
        issues: ['Some long sentences detected'],
      },
    };
    
    setResult(mockResult);
    setIsAnalyzing(false);
    setActiveTab('results');
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-amber-600';
    return 'text-red-600';
  };

  const getScoreBg = (score: number) => {
    if (score >= 80) return 'bg-green-100';
    if (score >= 60) return 'bg-amber-100';
    return 'bg-red-100';
  };

  return (
    <div className="min-h-screen bg-[#F6F8FB] pt-24 pb-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-3xl font-bold text-[#0B0F1A]">ATS Resume Checker</h1>
          <p className="mt-2 text-[#6B7280] max-w-lg mx-auto">
            Optimize your resume for Applicant Tracking Systems. Get instant feedback on keywords, formatting, and readability.
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 max-w-md mx-auto mb-8">
            <TabsTrigger value="upload">Upload & Analyze</TabsTrigger>
            <TabsTrigger value="results" disabled={!result}>Results</TabsTrigger>
          </TabsList>

          <TabsContent value="upload">
            <Card className="card-modern border-none">
              <CardContent className="p-8">
                {/* Upload Area */}
                <div className="border-2 border-dashed border-gray-200 rounded-2xl p-12 text-center hover:border-[#2F8E92] transition-colors cursor-pointer mb-8">
                  <div className="w-16 h-16 bg-[#2F8E92]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Upload className="w-8 h-8 text-[#2F8E92]" />
                  </div>
                  <h3 className="text-lg font-semibold text-[#0B0F1A]">Upload your resume</h3>
                  <p className="text-[#6B7280] mt-2">Drag and drop or click to browse (PDF, DOCX)</p>
                  <p className="text-sm text-[#6B7280] mt-1">Max file size: 5MB</p>
                </div>

                {/* Job Description */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label className="text-base font-medium">Paste job description</Label>
                    <span className="text-sm text-[#6B7280]">Optional but recommended</span>
                  </div>
                  <Textarea 
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    placeholder="Paste the job description here to get targeted keyword analysis..."
                    rows={6}
                  />
                </div>

                {/* Analyze Button */}
                <Button 
                  onClick={analyzeResume}
                  disabled={isAnalyzing}
                  className="w-full mt-6 btn-primary h-14 text-lg"
                >
                  {isAnalyzing ? (
                    <>
                      <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Target className="w-5 h-5 mr-2" />
                      Analyze Resume
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="results">
            {result && (
              <div className="space-y-6">
                {/* Overall Score */}
                <Card className="card-modern border-none">
                  <CardContent className="p-8">
                    <div className="flex flex-col md:flex-row items-center gap-8">
                      <div className={`w-32 h-32 ${getScoreBg(result.score)} rounded-full flex items-center justify-center`}>
                        <div className="text-center">
                          <span className={`text-4xl font-bold ${getScoreColor(result.score)}`}>
                            {result.score}
                          </span>
                          <p className="text-sm text-[#6B7280]">/ 100</p>
                        </div>
                      </div>
                      <div className="flex-1 text-center md:text-left">
                        <h3 className="text-2xl font-bold text-[#0B0F1A]">
                          {result.score >= 80 ? 'Great job!' : result.score >= 60 ? 'Good start!' : 'Needs improvement'}
                        </h3>
                        <p className="text-[#6B7280] mt-2">
                          {result.score >= 80 
                            ? 'Your resume is well-optimized for ATS systems.' 
                            : result.score >= 60 
                              ? 'Your resume is decent but could use some improvements.' 
                              : 'Your resume needs significant improvements to pass ATS filters.'}
                        </p>
                        <div className="flex flex-wrap gap-2 mt-4 justify-center md:justify-start">
                          <Badge variant="secondary" className="bg-green-100 text-green-700">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            {result.keywords.found.length} keywords found
                          </Badge>
                          <Badge variant="secondary" className="bg-red-100 text-red-700">
                            <XCircle className="w-3 h-3 mr-1" />
                            {result.keywords.missing.length} keywords missing
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Detailed Analysis */}
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Keywords */}
                  <Card className="card-modern border-none">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 bg-[#2F8E92]/10 rounded-lg flex items-center justify-center">
                          <Target className="w-5 h-5 text-[#2F8E92]" />
                        </div>
                        <h4 className="font-semibold text-[#0B0F1A]">Keywords Analysis</h4>
                      </div>
                      
                      <div className="space-y-4">
                        <div>
                          <p className="text-sm font-medium text-green-600 mb-2">Found ({result.keywords.found.length})</p>
                          <div className="flex flex-wrap gap-2">
                            {result.keywords.found.map((kw) => (
                              <Badge key={kw} variant="secondary" className="bg-green-100 text-green-700">
                                <CheckCircle className="w-3 h-3 mr-1" />
                                {kw}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm font-medium text-red-600 mb-2">Missing ({result.keywords.missing.length})</p>
                          <div className="flex flex-wrap gap-2">
                            {result.keywords.missing.map((kw) => (
                              <Badge key={kw} variant="secondary" className="bg-red-100 text-red-700">
                                <XCircle className="w-3 h-3 mr-1" />
                                {kw}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm font-medium text-amber-600 mb-2">Suggested</p>
                          <div className="flex flex-wrap gap-2">
                            {result.keywords.suggested.map((kw) => (
                              <Badge key={kw} variant="secondary" className="bg-amber-100 text-amber-700">
                                <Lightbulb className="w-3 h-3 mr-1" />
                                {kw}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Formatting */}
                  <Card className="card-modern border-none">
                    <CardContent className="p-6">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                          <FileText className="w-5 h-5 text-purple-600" />
                        </div>
                        <h4 className="font-semibold text-[#0B0F1A]">Formatting</h4>
                      </div>
                      
                      <div className="space-y-4">
                        {result.formatting.issues.length > 0 && (
                          <div>
                            <p className="text-sm font-medium text-red-600 mb-2">Issues Found</p>
                            <ul className="space-y-2">
                              {result.formatting.issues.map((issue, i) => (
                                <li key={i} className="flex items-start gap-2 text-sm text-[#0B0F1A]">
                                  <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                                  {issue}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        <div>
                          <p className="text-sm font-medium text-green-600 mb-2">Suggestions</p>
                          <ul className="space-y-2">
                            {result.formatting.suggestions.map((sugg, i) => (
                              <li key={i} className="flex items-start gap-2 text-sm text-[#0B0F1A]">
                                <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                                {sugg}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Readability */}
                <Card className="card-modern border-none">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <BarChart3 className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-[#0B0F1A]">Readability Score</h4>
                        <p className="text-sm text-[#6B7280]">{result.readability.score}/100</p>
                      </div>
                    </div>
                    <Progress value={result.readability.score} className="h-2" />
                    {result.readability.issues.length > 0 && (
                      <div className="mt-4">
                        <p className="text-sm font-medium text-amber-600 mb-2">Improvements</p>
                        <ul className="space-y-2">
                          {result.readability.issues.map((issue, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-[#0B0F1A]">
                              <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                              {issue}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Actions */}
                <div className="flex gap-4">
                  <Button 
                    onClick={() => setActiveTab('upload')}
                    variant="outline"
                    className="flex-1"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Analyze Another
                  </Button>
                  <Button className="flex-1 btn-primary">
                    View Optimized Resume
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// Need to add Label component
import { Label } from '@/components/ui/label';
