import { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Bot, 
  User as UserIcon, 
  Sparkles, 
  Mic, 
  MicOff,
  Lightbulb,
  Briefcase,
  FileText,
  Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { User, ChatMessage } from '@/types';

interface AIAssistantProps {
  user: User;
}

const suggestedPrompts = [
  { icon: Briefcase, text: 'Help me prepare for a product manager interview' },
  { icon: FileText, text: 'Review my resume summary' },
  { icon: Lightbulb, text: 'What skills should I learn for tech?' },
  { icon: Calendar, text: 'How do I negotiate salary?' },
];

const mockResponses: Record<string, string> = {
  'interview': `Here are some key tips for your interview:

1. **Research the company** - Understand their products, culture, and recent news
2. **Prepare STAR stories** - Situation, Task, Action, Result for behavioral questions
3. **Ask thoughtful questions** - Show your interest and curiosity
4. **Practice aloud** - Rehearse your answers to common questions

Would you like me to help you practice specific questions?`,

  'resume': `Your resume looks good! Here are some suggestions:

✅ Strong action verbs
✅ Clear metrics and achievements
⚠️ Consider adding more keywords from the job description
✅ Good formatting and readability

Your experience section is particularly strong. Would you like help with any specific section?`,

  'skills': `Based on current market trends, here are valuable skills to consider:

**Technical:**
- Python or JavaScript
- Data analysis (SQL, Excel)
- Cloud platforms (AWS, Azure)

**Soft Skills:**
- Communication
- Project management
- Problem-solving

Would you like a personalized learning path?`,

  'salary': `Salary negotiation tips:

1. **Research market rates** - Use sites like Glassdoor, Levels.fyi
2. **Know your worth** - Consider your experience and location
3. **Wait for the offer** - Don't disclose your current salary early
4. **Consider total compensation** - Base + equity + benefits
5. **Practice the conversation** - Be confident and professional

Want to practice your negotiation script?`,
};

export function AIAssistant({ user }: AIAssistantProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: `Hi ${user.name.split(' ')[0]}! I'm your AI career assistant. I can help you with:

• Interview preparation
• Resume feedback
• Career advice
• Salary negotiation
• Skill development

What would you like to work on today?`,
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async (content: string) => {
    if (!content.trim()) return;

    const userMessage: ChatMessage = {
      id: Math.random().toString(36).substr(2, 9),
      role: 'user',
      content,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    await new Promise(resolve => setTimeout(resolve, 1500));

    let response = '';
    const lowerContent = content.toLowerCase();
    
    if (lowerContent.includes('interview')) response = mockResponses['interview'];
    else if (lowerContent.includes('resume')) response = mockResponses['resume'];
    else if (lowerContent.includes('skill') || lowerContent.includes('learn')) response = mockResponses['skills'];
    else if (lowerContent.includes('salary') || lowerContent.includes('negotiate')) response = mockResponses['salary'];
    else {
      response = `That's a great question! I'd be happy to help with that.

Based on what you've shared, here are my thoughts:

1. Take time to reflect on your goals
2. Research best practices in your field
3. Consider seeking mentorship
4. Build a plan with actionable steps

Would you like me to elaborate on any of these points?`;
    }

    const assistantMessage: ChatMessage = {
      id: Math.random().toString(36).substr(2, 9),
      role: 'assistant',
      content: response,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, assistantMessage]);
    setIsTyping(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  const toggleRecording = () => {
    setIsRecording(!isRecording);
    // In a real app, this would start/stop voice recording
  };

  return (
    <div className="min-h-screen bg-[#F6F8FB] pt-24 pb-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#2F8E92]/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Bot className="w-8 h-8 text-[#2F8E92]" />
          </div>
          <h1 className="text-3xl font-bold text-[#0B0F1A]">AI Career Assistant</h1>
          <p className="mt-2 text-[#6B7280]">Your personal career coach, available 24/7</p>
        </div>

        {/* Suggested Prompts */}
        <div className="grid sm:grid-cols-2 gap-3 mb-8">
          {suggestedPrompts.map((prompt, i) => {
            const Icon = prompt.icon;
            return (
              <button
                key={i}
                onClick={() => sendMessage(prompt.text)}
                className="flex items-center gap-3 p-4 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow text-left"
              >
                <div className="w-10 h-10 bg-[#2F8E92]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon className="w-5 h-5 text-[#2F8E92]" />
                </div>
                <span className="text-sm text-[#0B0F1A]">{prompt.text}</span>
              </button>
            );
          })}
        </div>

        {/* Chat Area */}
        <Card className="card-modern border-none">
          <CardContent className="p-0">
            <ScrollArea className="h-[500px] p-6">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${
                      message.role === 'user' ? 'flex-row-reverse' : ''
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.role === 'user' 
                        ? 'bg-[#2F8E92]' 
                        : 'bg-[#2F8E92]/10'
                    }`}>
                      {message.role === 'user' ? (
                        <UserIcon className="w-4 h-4 text-white" />
                      ) : (
                        <Sparkles className="w-4 h-4 text-[#2F8E92]" />
                      )}
                    </div>
                    <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                      message.role === 'user'
                        ? 'bg-[#2F8E92] text-white'
                        : 'bg-gray-100 text-[#0B0F1A]'
                    }`}>
                      <p className="whitespace-pre-line text-sm">{message.content}</p>
                      <span className={`text-xs mt-1 block ${
                        message.role === 'user' ? 'text-white/70' : 'text-[#6B7280]'
                      }`}>
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex gap-3">
                    <div className="w-8 h-8 bg-[#2F8E92]/10 rounded-full flex items-center justify-center">
                      <Sparkles className="w-4 h-4 text-[#2F8E92]" />
                    </div>
                    <div className="bg-gray-100 rounded-2xl px-4 py-3">
                      <div className="flex gap-1">
                        <span className="w-2 h-2 bg-[#6B7280] rounded-full animate-bounce" />
                        <span className="w-2 h-2 bg-[#6B7280] rounded-full animate-bounce delay-100" />
                        <span className="w-2 h-2 bg-[#6B7280] rounded-full animate-bounce delay-200" />
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={scrollRef} />
              </div>
            </ScrollArea>

            {/* Input Area */}
            <form onSubmit={handleSubmit} className="p-4 border-t border-gray-100">
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={toggleRecording}
                  className={isRecording ? 'text-red-500' : ''}
                >
                  {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </Button>
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1"
                />
                <Button 
                  type="submit" 
                  className="btn-primary"
                  disabled={!input.trim()}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
