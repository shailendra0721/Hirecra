import { useState } from 'react';
import { 
  Plus, 
  Search, 
  Filter, 
  Building2, 
  MapPin,
  Clock,
  ChevronRight,
  TrendingUp,
  CheckCircle2,
  XCircle,
  Clock4,
  Users,
  Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { User, Application } from '@/types';

interface ApplicationTrackerProps {
  user: User;
}

const statusConfig = {
  applied: { label: 'Applied', color: 'bg-blue-100 text-blue-700', icon: Clock4 },
  screening: { label: 'Screening', color: 'bg-amber-100 text-amber-700', icon: Users },
  interview: { label: 'Interview', color: 'bg-purple-100 text-purple-700', icon: Calendar },
  offer: { label: 'Offer', color: 'bg-green-100 text-green-700', icon: CheckCircle2 },
  rejected: { label: 'Rejected', color: 'bg-red-100 text-red-700', icon: XCircle },
  withdrawn: { label: 'Withdrawn', color: 'bg-gray-100 text-gray-700', icon: XCircle },
};

const mockApplications: Application[] = [
  {
    id: '1',
    jobId: '1',
    userId: 'user1',
    status: 'interview',
    appliedAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    notes: 'Second round interview scheduled',
  },
  {
    id: '2',
    jobId: '2',
    userId: 'user1',
    status: 'screening',
    appliedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    notes: 'Phone screen completed, waiting for feedback',
  },
  {
    id: '3',
    jobId: '3',
    userId: 'user1',
    status: 'applied',
    appliedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
  },
  {
    id: '4',
    jobId: '4',
    userId: 'user1',
    status: 'offer',
    appliedAt: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    notes: 'Negotiating salary',
  },
  {
    id: '5',
    jobId: '5',
    userId: 'user1',
    status: 'rejected',
    appliedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
  },
];

const jobDetails: Record<string, { company: string; role: string; location: string }> = {
  '1': { company: 'Stripe', role: 'Senior Frontend Engineer', location: 'Remote' },
  '2': { company: 'Notion', role: 'Product Designer', location: 'San Francisco, CA' },
  '3': { company: 'Figma', role: 'Design Engineer', location: 'Remote' },
  '4': { company: 'Vercel', role: 'Full Stack Developer', location: 'New York, NY' },
  '5': { company: 'Airbnb', role: 'UX Researcher', location: 'San Francisco, CA' },
};

export function ApplicationTracker({ }: ApplicationTrackerProps) {
  const [applications, setApplications] = useState(mockApplications);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const filteredApps = applications.filter(app => {
    const job = jobDetails[app.jobId];
    const matchesSearch = job.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         job.company.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || app.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: applications.length,
    active: applications.filter(a => !['rejected', 'withdrawn', 'offer'].includes(a.status)).length,
    interviews: applications.filter(a => a.status === 'interview').length,
    offers: applications.filter(a => a.status === 'offer').length,
  };

  const updateStatus = (appId: string, newStatus: Application['status']) => {
    setApplications(prev => prev.map(app => 
      app.id === appId 
        ? { ...app, status: newStatus, updatedAt: new Date() }
        : app
    ));
  };

  return (
    <div className="min-h-screen bg-[#F6F8FB] pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-[#0B0F1A]">Application Tracker</h1>
            <p className="mt-2 text-[#6B7280]">Keep track of all your job applications in one place</p>
          </div>
          <Button className="btn-primary">
            <Plus className="w-4 h-4 mr-2" />
            Add Application
          </Button>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="card-modern border-none">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[#6B7280]">Total Applications</p>
                  <p className="text-2xl font-bold text-[#0B0F1A]">{stats.total}</p>
                </div>
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-5 h-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="card-modern border-none">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[#6B7280]">Active</p>
                  <p className="text-2xl font-bold text-[#0B0F1A]">{stats.active}</p>
                </div>
                <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                  <Clock4 className="w-5 h-5 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="card-modern border-none">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[#6B7280]">Interviews</p>
                  <p className="text-2xl font-bold text-[#0B0F1A]">{stats.interviews}</p>
                </div>
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="card-modern border-none">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-[#6B7280]">Offers</p>
                  <p className="text-2xl font-bold text-[#0B0F1A]">{stats.offers}</p>
                </div>
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="card-modern border-none mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6B7280]" />
                <Input 
                  placeholder="Search applications..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="applied">Applied</SelectItem>
                  <SelectItem value="screening">Screening</SelectItem>
                  <SelectItem value="interview">Interview</SelectItem>
                  <SelectItem value="offer">Offer</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Applications List */}
        <div className="space-y-4">
          {filteredApps.map((app) => {
            const job = jobDetails[app.jobId];
            const status = statusConfig[app.status];
            const StatusIcon = status.icon;
            
            return (
              <Dialog key={app.id}>
                <DialogTrigger asChild>
                  <Card className="card-modern border-none hover:shadow-[0_24px_60px_rgba(11,15,26,0.10)] transition-shadow cursor-pointer">
                    <CardContent className="p-6">
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 bg-[#2F8E92]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                            <Building2 className="w-6 h-6 text-[#2F8E92]" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-[#0B0F1A]">{job.role}</h3>
                            <p className="text-[#6B7280]">{job.company}</p>
                            <div className="flex items-center gap-3 mt-2">
                              <span className="text-sm text-[#6B7280] flex items-center gap-1">
                                <MapPin className="w-3 h-3" />
                                {job.location}
                              </span>
                              <span className="text-sm text-[#6B7280] flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                Applied {Math.floor((Date.now() - app.appliedAt.getTime()) / (1000 * 60 * 60 * 24))} days ago
                              </span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center gap-3">
                          <Badge className={status.color}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {status.label}
                          </Badge>
                          <Button variant="ghost" size="icon">
                            <ChevronRight className="w-5 h-5" />
                          </Button>
                        </div>
                      </div>
                      
                      {/* Progress Bar */}
                      <div className="mt-4">
                        <div className="flex justify-between text-xs text-[#6B7280] mb-1">
                          <span>Applied</span>
                          <span>Screening</span>
                          <span>Interview</span>
                          <span>Offer</span>
                        </div>
                        <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-[#2F8E92] transition-all"
                            style={{ 
                              width: app.status === 'applied' ? '25%' : 
                                     app.status === 'screening' ? '50%' : 
                                     app.status === 'interview' ? '75%' : 
                                     app.status === 'offer' ? '100%' : '0%' 
                            }}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </DialogTrigger>
                
                <DialogContent className="max-w-lg">
                  <DialogHeader>
                    <DialogTitle>{job.role}</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-[#2F8E92]/10 rounded-xl flex items-center justify-center">
                        <Building2 className="w-6 h-6 text-[#2F8E92]" />
                      </div>
                      <div>
                        <p className="font-medium">{job.company}</p>
                        <p className="text-sm text-[#6B7280]">{job.location}</p>
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-sm font-medium mb-2">Update Status</p>
                      <div className="flex flex-wrap gap-2">
                        {Object.entries(statusConfig).map(([key, config]) => (
                          <button
                            key={key}
                            onClick={() => updateStatus(app.id, key as Application['status'])}
                            className={`px-3 py-1.5 rounded-full text-sm font-medium transition-colors ${
                              app.status === key 
                                ? config.color 
                                : 'bg-gray-100 text-[#6B7280] hover:bg-gray-200'
                            }`}
                          >
                            {config.label}
                          </button>
                        ))}
                      </div>
                    </div>
                    
                    {app.notes && (
                      <div>
                        <p className="text-sm font-medium mb-1">Notes</p>
                        <p className="text-sm text-[#6B7280]">{app.notes}</p>
                      </div>
                    )}
                    
                    <div className="flex gap-2 text-sm text-[#6B7280]">
                      <span>Applied: {app.appliedAt.toLocaleDateString()}</span>
                      <span>•</span>
                      <span>Last updated: {app.updatedAt.toLocaleDateString()}</span>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            );
          })}
        </div>

        {filteredApps.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-[#6B7280]" />
            </div>
            <h3 className="text-lg font-semibold text-[#0B0F1A]">No applications found</h3>
            <p className="text-[#6B7280] mt-2">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </div>
  );
}
