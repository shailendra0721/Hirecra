export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  avatar?: string;
  createdAt: Date;
}

export interface Job {
  id: string;
  title: string;
  company: string;
  companyLogo?: string;
  location: string;
  type: 'full-time' | 'part-time' | 'contract' | 'remote' | 'hybrid';
  salary: {
    min: number;
    max: number;
    currency: string;
    period: 'year' | 'hour';
  };
  description: string;
  requirements: string[];
  benefits: string[];
  postedAt: Date;
  deadline?: Date;
  category: string;
}

export interface Application {
  id: string;
  jobId: string;
  userId: string;
  status: 'applied' | 'screening' | 'interview' | 'offer' | 'rejected' | 'withdrawn';
  appliedAt: Date;
  updatedAt: Date;
  notes?: string;
  resumeVersion?: string;
  coverLetter?: string;
}

export interface Resume {
  id: string;
  userId: string;
  template: string;
  content: {
    personalInfo: {
      fullName: string;
      email: string;
      phone: string;
      location: string;
      linkedin?: string;
      website?: string;
    };
    summary: string;
    experience: Experience[];
    education: Education[];
    skills: string[];
    certifications?: Certification[];
    projects?: Project[];
  };
  atsScore?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Experience {
  id: string;
  company: string;
  title: string;
  location: string;
  startDate: string;
  endDate?: string;
  current: boolean;
  description: string;
  achievements: string[];
}

export interface Education {
  id: string;
  institution: string;
  degree: string;
  field: string;
  location: string;
  startDate: string;
  endDate?: string;
  current: boolean;
  gpa?: string;
}

export interface Certification {
  id: string;
  name: string;
  issuer: string;
  date: string;
  expiry?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  technologies: string[];
  link?: string;
}

export interface ATSResult {
  score: number;
  keywords: {
    found: string[];
    missing: string[];
    suggested: string[];
  };
  formatting: {
    issues: string[];
    suggestions: string[];
  };
  readability: {
    score: number;
    issues: string[];
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  avatar: string;
  quote: string;
}

export interface PricingPlan {
  id: string;
  name: string;
  price: number;
  period: 'month' | 'year';
  description: string;
  features: string[];
  highlighted?: boolean;
  cta: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  image: string;
  author: string;
  publishedAt: Date;
  category: string;
  readTime: number;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
}
