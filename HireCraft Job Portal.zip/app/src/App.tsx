import { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { HeroSection } from './sections/HeroSection';
import { JobSearchSection } from './sections/JobSearchSection';
import { FeaturedJobsSection } from './sections/FeaturedJobsSection';
import { ResumeBuilderSection } from './sections/ResumeBuilderSection';
import { ATSCheckerSection } from './sections/ATSCheckerSection';
import { TrackerSection } from './sections/TrackerSection';
import { AIAssistantSection } from './sections/AIAssistantSection';
import { TestimonialsSection } from './sections/TestimonialsSection';
import { PricingSection } from './sections/PricingSection';
import { BlogSection } from './sections/BlogSection';
import { NewsletterSection } from './sections/NewsletterSection';
import { FAQSection } from './sections/FAQSection';
import { ValuesSection } from './sections/ValuesSection';
import { PartnersSection } from './sections/PartnersSection';
import { Footer } from './sections/Footer';
import { AuthModal } from './components/AuthModal';
import { Dashboard } from './pages/Dashboard';
import { JobsPage } from './pages/JobsPage';
import { ResumeBuilder } from './pages/ResumeBuilder';
import { ATSChecker } from './pages/ATSChecker';
import { ApplicationTracker } from './pages/ApplicationTracker';
import { AIAssistant } from './pages/AIAssistant';
import { AdminPanel } from './pages/AdminPanel';
import { ChatBot } from './components/ChatBot';
import type { User } from './types';

export type View = 'home' | 'dashboard' | 'jobs' | 'resume' | 'ats' | 'tracker' | 'assistant' | 'admin';

function App() {
  const [currentView, setCurrentView] = useState<View>('home');
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for saved user session
    const savedUser = localStorage.getItem('hirecraft_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setIsLoading(false);
  }, []);

  const handleLogin = (userData: User) => {
    setUser(userData);
    localStorage.setItem('hirecraft_user', JSON.stringify(userData));
    setIsAuthOpen(false);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('hirecraft_user');
    setCurrentView('home');
  };

  const openAuth = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setIsAuthOpen(true);
  };

  const navigateTo = (view: View) => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F6F8FB]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#2F8E92]"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F6F8FB] relative">
      {/* Grain Overlay */}
      <div className="grain-overlay" />
      
      {/* Navigation */}
      <Navigation 
        user={user}
        currentView={currentView}
        onNavigate={navigateTo}
        onOpenAuth={openAuth}
        onLogout={handleLogout}
      />

      {/* Main Content */}
      <main>
        {currentView === 'home' && (
          <>
            <HeroSection onGetStarted={() => openAuth('register')} />
            <JobSearchSection onSearch={() => navigateTo('jobs')} />
            <FeaturedJobsSection onViewAll={() => navigateTo('jobs')} />
            <ResumeBuilderSection onCreateResume={() => navigateTo('resume')} />
            <ATSCheckerSection onCheckResume={() => navigateTo('ats')} />
            <TrackerSection onTrackApplications={() => navigateTo('tracker')} />
            <AIAssistantSection onTryAssistant={() => navigateTo('assistant')} />
            <TestimonialsSection />
            <PricingSection />
            <BlogSection />
            <NewsletterSection />
            <FAQSection />
            <ValuesSection />
            <PartnersSection />
            <Footer onNavigate={navigateTo} />
          </>
        )}
        
        {currentView === 'dashboard' && user && (
          <Dashboard user={user} onNavigate={navigateTo} />
        )}
        
        {currentView === 'jobs' && (
          <JobsPage user={user} onLogin={() => openAuth('login')} />
        )}
        
        {currentView === 'resume' && user && (
          <ResumeBuilder user={user} />
        )}
        
        {currentView === 'ats' && user && (
          <ATSChecker user={user} />
        )}
        
        {currentView === 'tracker' && user && (
          <ApplicationTracker user={user} />
        )}
        
        {currentView === 'assistant' && user && (
          <AIAssistant user={user} />
        )}
        
        {currentView === 'admin' && user?.role === 'admin' && (
          <AdminPanel user={user} />
        )}
      </main>

      {/* Auth Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        mode={authMode}
        onSwitchMode={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
        onLogin={handleLogin}
      />

      {/* AI ChatBot - Always visible when logged in */}
      {user && currentView !== 'assistant' && (
        <ChatBot user={user} minimized />
      )}
    </div>
  );
}

export default App;
