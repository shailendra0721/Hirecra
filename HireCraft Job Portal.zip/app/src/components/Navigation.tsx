import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Briefcase, 
  FileText, 
  CheckCircle, 
  BarChart3, 
  CreditCard,
  Menu,
  X,
  User as UserIcon,
  LogOut,
  ChevronDown
} from 'lucide-react';
import type { User } from '@/types';
import type { View } from '@/App';

interface NavigationProps {
  user: User | null;
  currentView: View;
  onNavigate: (view: View) => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onLogout: () => void;
}

const navLinks = [
  { label: 'Jobs', view: 'jobs' as View, icon: Briefcase },
  { label: 'Resume', view: 'resume' as View, icon: FileText },
  { label: 'ATS', view: 'ats' as View, icon: CheckCircle },
  { label: 'Tracker', view: 'tracker' as View, icon: BarChart3 },
  { label: 'Pricing', view: 'home' as View, icon: CreditCard, scrollTo: 'pricing' },
];

export function Navigation({ 
  user, 
  currentView, 
  onNavigate, 
  onOpenAuth, 
  onLogout 
}: NavigationProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (link: typeof navLinks[0]) => {
    if (link.scrollTo) {
      onNavigate('home');
      setTimeout(() => {
        const element = document.getElementById(link.scrollTo);
        element?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      onNavigate(link.view);
    }
    setIsMobileMenuOpen(false);
  };

  const isActive = (view: View) => currentView === view;

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled || currentView !== 'home'
          ? 'bg-white/90 backdrop-blur-md shadow-sm'
          : 'bg-transparent'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <button 
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 group"
          >
            <div className="w-8 h-8 lg:w-10 lg:h-10 bg-[#2F8E92] rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform">
              <Briefcase className="w-4 h-4 lg:w-5 lg:h-5 text-white" />
            </div>
            <span className="font-bold text-lg lg:text-xl text-[#0B0F1A]">HireCraft</span>
          </button>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => handleNavClick(link)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  isActive(link.view) && !link.scrollTo
                    ? 'bg-[#2F8E92]/10 text-[#2F8E92]'
                    : 'text-[#6B7280] hover:text-[#0B0F1A] hover:bg-gray-100'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center gap-3">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 px-3 py-2 rounded-full hover:bg-gray-100 transition-colors"
                >
                  <div className="w-8 h-8 bg-[#2F8E92] rounded-full flex items-center justify-center">
                    <UserIcon className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-sm font-medium text-[#0B0F1A]">{user.name}</span>
                  <ChevronDown className="w-4 h-4 text-[#6B7280]" />
                </button>

                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-lg border border-gray-100 py-2 animate-in fade-in slide-in-from-top-2">
                    <button
                      onClick={() => {
                        onNavigate('dashboard');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-[#0B0F1A] hover:bg-gray-50 flex items-center gap-2"
                    >
                      <BarChart3 className="w-4 h-4" />
                      Dashboard
                    </button>
                    {user.role === 'admin' && (
                      <button
                        onClick={() => {
                          onNavigate('admin');
                          setIsUserMenuOpen(false);
                        }}
                        className="w-full px-4 py-2 text-left text-sm text-[#0B0F1A] hover:bg-gray-50 flex items-center gap-2"
                      >
                        <Briefcase className="w-4 h-4" />
                        Admin Panel
                      </button>
                    )}
                    <hr className="my-2" />
                    <button
                      onClick={onLogout}
                      className="w-full px-4 py-2 text-left text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Button
                  variant="ghost"
                  onClick={() => onOpenAuth('login')}
                  className="text-[#0B0F1A] hover:text-[#2F8E92]"
                >
                  Sign in
                </Button>
                <Button
                  onClick={() => onOpenAuth('register')}
                  className="btn-primary"
                >
                  Get started
                </Button>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100"
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6 text-[#0B0F1A]" />
            ) : (
              <Menu className="w-6 h-6 text-[#0B0F1A]" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden bg-white border-t border-gray-100 py-4 animate-in slide-in-from-top">
            <div className="flex flex-col gap-2">
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => handleNavClick(link)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-colors ${
                    isActive(link.view) && !link.scrollTo
                      ? 'bg-[#2F8E92]/10 text-[#2F8E92]'
                      : 'text-[#0B0F1A] hover:bg-gray-50'
                  }`}
                >
                  <link.icon className="w-5 h-5" />
                  {link.label}
                </button>
              ))}
              
              <hr className="my-2" />
              
              {user ? (
                <>
                  <button
                    onClick={() => {
                      onNavigate('dashboard');
                      setIsMobileMenuOpen(false);
                    }}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl text-left text-[#0B0F1A] hover:bg-gray-50"
                  >
                    <BarChart3 className="w-5 h-5" />
                    Dashboard
                  </button>
                  <button
                    onClick={onLogout}
                    className="flex items-center gap-3 px-4 py-3 rounded-xl text-left text-red-600 hover:bg-red-50"
                  >
                    <LogOut className="w-5 h-5" />
                    Sign out
                  </button>
                </>
              ) : (
                <div className="flex flex-col gap-2 px-4">
                  <Button
                    variant="outline"
                    onClick={() => {
                      onOpenAuth('login');
                      setIsMobileMenuOpen(false);
                    }}
                    className="w-full"
                  >
                    Sign in
                  </Button>
                  <Button
                    onClick={() => {
                      onOpenAuth('register');
                      setIsMobileMenuOpen(false);
                    }}
                    className="btn-primary w-full"
                  >
                    Get started
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
