import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { Briefcase, Eye, EyeOff, Loader2 } from 'lucide-react';
import type { User } from '@/types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  mode: 'login' | 'register';
  onSwitchMode: () => void;
  onLogin: (user: User) => void;
}

export function AuthModal({ isOpen, onClose, mode, onSwitchMode, onLogin }: AuthModalProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    agreeToTerms: false,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (mode === 'register' && !formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }
    
    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }
    
    if (mode === 'register' && !formData.agreeToTerms) {
      newErrors.terms = 'You must agree to the terms';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Create mock user
    const user: User = {
      id: Math.random().toString(36).substr(2, 9),
      email: formData.email,
      name: mode === 'register' ? formData.name : formData.email.split('@')[0],
      role: formData.email.includes('admin') ? 'admin' : 'user',
      createdAt: new Date(),
    };
    
    onLogin(user);
    setIsLoading(false);
    setFormData({ name: '', email: '', password: '', agreeToTerms: false });
  };

  const handleQuickLogin = (type: 'user' | 'admin') => {
    const user: User = {
      id: Math.random().toString(36).substr(2, 9),
      email: type === 'admin' ? 'admin@hirecraft.io' : 'user@example.com',
      name: type === 'admin' ? 'Admin User' : 'John Doe',
      role: type,
      createdAt: new Date(),
    };
    onLogin(user);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-white rounded-3xl p-0 overflow-hidden">
        <div className="p-6 sm:p-8">
          <DialogHeader className="text-center mb-6">
            <div className="mx-auto w-12 h-12 bg-[#2F8E92] rounded-xl flex items-center justify-center mb-4">
              <Briefcase className="w-6 h-6 text-white" />
            </div>
            <DialogTitle className="text-2xl font-bold text-[#0B0F1A]">
              {mode === 'login' ? 'Welcome back' : 'Create your account'}
            </DialogTitle>
            <p className="text-[#6B7280] text-sm mt-2">
              {mode === 'login' 
                ? 'Sign in to access your dashboard and applications' 
                : 'Start your career journey with HireCraft'}
            </p>
          </DialogHeader>

          <Tabs value={mode} onValueChange={(v) => v !== mode && onSwitchMode()} className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6">
              <TabsTrigger value="login">Sign in</TabsTrigger>
              <TabsTrigger value="register">Sign up</TabsTrigger>
            </TabsList>

            <TabsContent value={mode}>
              <form onSubmit={handleSubmit} className="space-y-4">
                {mode === 'register' && (
                  <div className="space-y-2">
                    <Label htmlFor="name">Full name</Label>
                    <Input
                      id="name"
                      placeholder="John Doe"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className={`h-12 rounded-xl ${errors.name ? 'border-red-500' : ''}`}
                    />
                    {errors.name && <p className="text-red-500 text-xs">{errors.name}</p>}
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="email">Email address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className={`h-12 rounded-xl ${errors.email ? 'border-red-500' : ''}`}
                  />
                  {errors.email && <p className="text-red-500 text-xs">{errors.email}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? 'text' : 'password'}
                      placeholder="••••••••"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className={`h-12 rounded-xl pr-10 ${errors.password ? 'border-red-500' : ''}`}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B7280] hover:text-[#0B0F1A]"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                  {errors.password && <p className="text-red-500 text-xs">{errors.password}</p>}
                </div>

                {mode === 'register' && (
                  <div className="flex items-start gap-2">
                    <Checkbox
                      id="terms"
                      checked={formData.agreeToTerms}
                      onCheckedChange={(checked) => 
                        setFormData({ ...formData, agreeToTerms: checked as boolean })
                      }
                      className={errors.terms ? 'border-red-500' : ''}
                    />
                    <label htmlFor="terms" className="text-sm text-[#6B7280] leading-tight">
                      I agree to the{' '}
                      <button type="button" className="text-[#2F8E92] hover:underline">Terms of Service</button>
                      {' '}and{' '}
                      <button type="button" className="text-[#2F8E92] hover:underline">Privacy Policy</button>
                    </label>
                  </div>
                )}

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-12 btn-primary"
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : mode === 'login' ? (
                    'Sign in'
                  ) : (
                    'Create account'
                  )}
                </Button>
              </form>
            </TabsContent>
          </Tabs>

          {/* Quick Login for Demo */}
          <div className="mt-6 pt-6 border-t border-gray-100">
            <p className="text-xs text-center text-[#6B7280] mb-3">Quick demo login</p>
            <div className="flex gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => handleQuickLogin('user')}
                className="flex-1 h-10 text-sm"
              >
                Demo User
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => handleQuickLogin('admin')}
                className="flex-1 h-10 text-sm"
              >
                Demo Admin
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
